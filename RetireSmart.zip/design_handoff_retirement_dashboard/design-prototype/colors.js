// Centralized color palette — semantic, not visual.
window.PALETTE = {
  // ACCOUNTS — greens (your money you have)
  account401k:    '#3FA76B',  // deep green
  accountTax:     '#5FBF8F',  // medium green
  accountRoth:    '#86D6AC',  // light green
  accountCash:    '#B8E5C9',  // pale green

  // SPENDING — yellow/amber
  spend:          '#F2C94C',
  spendDim:       'rgba(242, 201, 76, 0.5)',
  spendBump:      '#F2A93C',  // override marker, deeper amber

  // INCOME — cool/neutral, not competing with green/red
  wages:          '#7AB8D4',  // wages — soft blue
  other:          '#A89BD4',  // other income — soft purple
  ss:             '#6FB5A8',  // social security — teal
  pension:        '#B89BD4',  // pension — lavender

  // TAX — red (the enemy)
  tax:            '#E0584C',
  taxDim:         'rgba(224, 88, 76, 0.6)',

  // UI
  ink:            '#F2F1EC',
  inkSoft:        'rgba(242, 241, 236, 0.6)',
  inkSofter:      'rgba(242, 241, 236, 0.4)',
  bgDeep:         '#0A1410',
  bgMid:          '#0F1C18',
  bgLift:         'rgba(20, 34, 28, 0.7)',
  borderSoft:     'rgba(255, 255, 255, 0.06)',
  borderAccent:   'rgba(63, 167, 107, 0.22)',

  // States
  good:           '#7CD4A8',
  danger:         '#E0584C',
};
