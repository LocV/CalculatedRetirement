// Chart.jsx — main projection chart (stacked area)
const { useMemo, useRef, useState, useEffect } = React;

function fmt(n) {
  if (n === null || n === undefined || isNaN(n)) return '—';
  const abs = Math.abs(n);
  if (abs >= 1e6) return '$' + (n / 1e6).toFixed(2) + 'M';
  if (abs >= 1e3) return '$' + (n / 1e3).toFixed(0) + 'k';
  return '$' + Math.round(n);
}
function fmtFull(n) {
  if (n === null || n === undefined || isNaN(n)) return '—';
  return '$' + Math.round(n).toLocaleString();
}

function ProjectionChart({ rows, hoverAge, setHoverAge, retireAge, depleted }) {
  const P = window.PALETTE;
  const wrapRef = useRef(null);
  const [w, setW] = useState(960);
  const h = 380;
  const padL = 64, padR = 24, padT = 24, padB = 36;

  useEffect(() => {
    const obs = new ResizeObserver(entries => {
      for (const e of entries) setW(Math.max(400, e.contentRect.width));
    });
    if (wrapRef.current) obs.observe(wrapRef.current);
    return () => obs.disconnect();
  }, []);

  const innerW = w - padL - padR;
  const innerH = h - padT - padB;

  const maxAssets = useMemo(
    () => Math.max(...rows.map(r => r.totalAssets), 1),
    [rows]
  );

  const x = age => padL + ((age - rows[0].age) / (rows[rows.length-1].age - rows[0].age)) * innerW;
  const yA = v => padT + innerH - (v / maxAssets) * innerH;

  const areaPath = (key, base) => {
    const top = rows.map(r => `${x(r.age)},${yA((base ? base(r) : 0) + r[key])}`);
    const bot = [...rows].reverse().map(r => `${x(r.age)},${yA(base ? base(r) : 0)}`);
    return `M${top.join(' L')} L${bot.join(' L')} Z`;
  };

  const totalLine = rows.map(r => `${x(r.age)},${yA(r.totalAssets)}`).join(' L');

  const ticks = 5;
  const tickVals = Array.from({length: ticks+1}, (_, i) => (maxAssets / ticks) * i);
  const ageTicks = rows.filter(r => r.age % 5 === 0);
  const hover = rows.find(r => r.age === hoverAge);

  return (
    <div ref={wrapRef} style={{ width: '100%' }}>
      <svg
        width={w} height={h}
        onMouseMove={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const px = e.clientX - rect.left;
          const ageF = rows[0].age + ((px - padL) / innerW) * (rows[rows.length-1].age - rows[0].age);
          const a = Math.round(ageF);
          if (a >= rows[0].age && a <= rows[rows.length-1].age) setHoverAge(a);
        }}
        onMouseLeave={() => setHoverAge(null)}
        style={{ display: 'block', cursor: 'crosshair' }}
      >
        {tickVals.map((v, i) => (
          <g key={i}>
            <line x1={padL} x2={w-padR} y1={yA(v)} y2={yA(v)}
                  stroke="rgba(255,255,255,0.06)" strokeWidth="1" />
            <text x={padL-10} y={yA(v)+4} fill="rgba(255,255,255,0.45)"
                  fontSize="11" textAnchor="end" fontFamily="JetBrains Mono, monospace">
              {fmt(v)}
            </text>
          </g>
        ))}

        <line x1={x(retireAge)} x2={x(retireAge)} y1={padT} y2={padT+innerH}
              stroke="rgba(242, 201, 76, 0.45)" strokeWidth="1" strokeDasharray="3 4" />
        <text x={x(retireAge)+6} y={padT+12} fill="rgba(242,201,76,0.9)"
              fontSize="10" fontFamily="Inter Tight, sans-serif" letterSpacing="0.06em">
          RETIRE · {retireAge}
        </text>

        {depleted && (
          <>
            <line x1={x(depleted)} x2={x(depleted)} y1={padT} y2={padT+innerH}
                  stroke="rgba(224, 88, 76, 0.55)" strokeWidth="1" strokeDasharray="3 4" />
            <text x={x(depleted)+6} y={padT+26} fill={P.danger}
                  fontSize="10" fontFamily="Inter Tight, sans-serif" letterSpacing="0.06em">
              DEPLETED · {depleted}
            </text>
          </>
        )}

        {/* Stacked accounts: 401k, taxable, roth, cash */}
        <path d={areaPath('b401k', () => 0)}                            fill={P.account401k} fillOpacity="0.85" />
        <path d={areaPath('bTax',  r => r.b401k)}                       fill={P.accountTax}  fillOpacity="0.85" />
        <path d={areaPath('bRoth', r => r.b401k + r.bTax)}              fill={P.accountRoth} fillOpacity="0.85" />
        <path d={areaPath('bCash', r => r.b401k + r.bTax + r.bRoth)}    fill={P.accountCash} fillOpacity="0.85" />

        <path d={`M${totalLine}`} fill="none" stroke="#F2F1EC" strokeWidth="1.5" />

        {ageTicks.map(r => (
          <g key={r.age}>
            <line x1={x(r.age)} x2={x(r.age)} y1={padT+innerH} y2={padT+innerH+4}
                  stroke="rgba(255,255,255,0.2)" />
            <text x={x(r.age)} y={padT+innerH+18} fill="rgba(255,255,255,0.5)"
                  fontSize="11" textAnchor="middle" fontFamily="JetBrains Mono, monospace">
              {r.age}
            </text>
          </g>
        ))}

        {hover && (
          <>
            <line x1={x(hover.age)} x2={x(hover.age)} y1={padT} y2={padT+innerH}
                  stroke="rgba(242,241,236,0.4)" strokeWidth="1" />
            <circle cx={x(hover.age)} cy={yA(hover.totalAssets)} r="4"
                    fill="#F2F1EC" stroke="#0A1410" strokeWidth="2" />
          </>
        )}
      </svg>
    </div>
  );
}

window.ProjectionChart = ProjectionChart;
window.fmt = fmt;
window.fmtFull = fmtFull;
