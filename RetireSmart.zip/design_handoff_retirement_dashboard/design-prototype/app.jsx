// app.jsx — RetireSmart dashboard
const { useState, useMemo, useCallback } = React;

const DEFAULTS = /*EDITMODE-BEGIN*/{
  "currentAge": 58,
  "retireAgeP1": 65,
  "retireAgeP2": 65,
  "spouseAgeOffset": 0,
  "ruleOf55Age": null,
  "endAge": 95,
  "balance401k": 720000,
  "balanceRoth": 145000,
  "balanceTaxable": 180000,
  "balanceCash": 60000,
  "contribution401k": 23000,
  "employerMatch": 7000,
  "returnRate": 0.06,
  "inflation": 0.025,
  "desiredSpend": 95000,
  "ssBenefit": 38400,
  "ssStartAge": 67,
  "pension": 0,
  "workIncomeP1": 100000,
  "workIncomeP2": 100000,
  "otherIncome": 0,
  "filing": "mfj",
  "spendOverrides": { "67": { "amount": 25000, "label": "Big trip to Italy" }, "72": { "amount": 40000, "label": "New car" } },
  "rothConversions": {},
  "incomeOverrides": {},
  "recurringExpenses": [
    { "label": "Mortgage", "amount": 28800, "startAge": 58, "endAge": 70 },
    { "label": "Car payment", "amount": 7200, "startAge": 58, "endAge": 63 }
  ]
}/*EDITMODE-END*/;

function App() {
  const P = window.PALETTE;
  const [state, setState] = useState(DEFAULTS);
  const [hoverAge, setHoverAge] = useState(null);
  const [openPanel, setOpenPanel] = useState(null);
  const [showIncomeEditor, setShowIncomeEditor] = useState(false);

  const update = useCallback((patch) => {
    setState(s => {
      const next = { ...s, ...patch };
      window.parent.postMessage({ type: '__edit_mode_set_keys', edits: patch }, '*');
      return next;
    });
  }, []);

  const result = useMemo(() => window.RetireMath.project(state), [state]);
  const rows = result.rows;
  const today = rows[0];
  const atRetire = rows.find(r => r.age === state.retireAgeP1) || rows[rows.length-1];
  const final = rows[rows.length - 1];
  const totalToday = today.b401k + today.bTax + today.bRoth + today.bCash;
  const totalAtRetire = atRetire.b401k + atRetire.bTax + atRetire.bRoth + atRetire.bCash;
  const lifetimeTax = rows.reduce((a, r) => a + r.fedTax, 0);
  const hoverRow = hoverAge ? rows.find(r => r.age === hoverAge) : null;

  const openFromChip = (id) => (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setOpenPanel({ id, anchor: { x: rect.left + rect.width/2, y: rect.bottom } });
  };

  const recurringCount = (state.recurringExpenses || []).length;

  return (
    <div style={{
      minHeight: '100vh',
      background: 'radial-gradient(ellipse at top, #0F2419 0%, #0A1410 60%, #060A08 100%)',
      color: P.ink,
      fontFamily: '"Inter Tight", system-ui, sans-serif',
      padding: '28px 36px 60px',
    }}>
      <header style={{ display: 'flex', alignItems: 'flex-end',
                       justifyContent: 'space-between', marginBottom: 28 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
            <div style={{ width: 8, height: 8, background: P.account401k,
                          transform: 'rotate(45deg)' }} />
            <span style={{ fontSize: 11, letterSpacing: '0.22em',
                           color: P.account401k, fontWeight: 600 }}>
              RETIRESMART
            </span>
          </div>
          <h1 style={{ margin: 0, fontSize: 34, fontWeight: 500,
                       letterSpacing: '-0.02em', lineHeight: 1.05 }}>
            Drawdown Atlas
          </h1>
          <p style={{ margin: '6px 0 0', fontSize: 13,
                      color: P.inkSoft, maxWidth: 540 }}>
            Year-by-year projection of assets, income, expenses, and taxes.
            Click any chip to open its control panel.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <Chip label={state.filing === 'mfj' ? 'Filing · Married/Joint' : 'Filing · Single'}
                onClick={openFromChip('filing')} />
          <Chip label={`Plan · ${state.currentAge} → ${state.endAge}`}
                onClick={openFromChip('horizon')} />
        </div>
      </header>

      {/* KPI strip */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)',
                    gap: 1, marginBottom: 24,
                    background: 'rgba(63,167,107,0.18)',
                    border: `1px solid ${P.borderAccent}`,
                    borderRadius: 4 }}>
        <Kpi label="Total today" value={window.fmtFull(totalToday)}
             sub={`Age ${state.currentAge}`} chip onClick={openFromChip('accounts')}
             accent={P.account401k} />
        <Kpi label={`At retirement · ${state.retireAgeP1}`}
             value={window.fmtFull(totalAtRetire)}
             sub={`+${window.fmt(totalAtRetire-totalToday)} growth`}
             accent={P.accountTax} />
        <Kpi label="Annual spend" value={window.fmtFull(state.desiredSpend)}
             sub="today's dollars" chip onClick={openFromChip('spend')}
             accent={P.spend} />
        <Kpi label="Lifetime tax" value={window.fmt(lifetimeTax)}
             sub={`${(lifetimeTax/(rows.reduce((a,r)=>a+r.grossIncome,0)||1)*100).toFixed(1)}% effective`}
             accent={P.tax} />
        <Kpi label={`At age ${state.endAge}`}
             value={window.fmt(final.totalAssets)}
             sub={result.depleted ? `Depleted at ${result.depleted}` : 'On track'}
             accent={result.depleted ? P.danger : P.good} />
      </div>

      {/* Cash flow — hero */}
      <Card>
        <CardHeader eyebrow="CASH FLOW — income vs expenses"
          title="Every year, in and out" accent={P.spend}
          right={
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <Chip small label={`P1 retire · ${state.retireAgeP1}`}
                    onClick={openFromChip('retire')} />
              <Chip small label={`P2 retire · ${state.retireAgeP2}`}
                    onClick={openFromChip('retire')} />
              <Chip small label={`Wages · ${window.fmt(state.workIncomeP1+state.workIncomeP2)}/yr`}
                    onClick={openFromChip('income')} />
              <Chip small label={`SS · ${window.fmt(state.ssBenefit)}/yr @ ${state.ssStartAge}`}
                    onClick={openFromChip('ss')} />
              <Chip small label={`Recurring · ${recurringCount} item${recurringCount===1?'':'s'}`}
                    onClick={openFromChip('recurring')} />
              <Chip small label={`Bumps · ${Object.keys(state.spendOverrides||{}).length}`}
                    onClick={openFromChip('spend')} />
              <Chip small label={`Roth conv · ${Object.keys(state.rothConversions||{}).length}`}
                    onClick={openFromChip('roth')} />
              <Chip small label={`Fine-tune by year →`}
                    onClick={() => setShowIncomeEditor(true)} />
            </div>
          } />
        <Legend items={[
          { c: P.wages,        l: 'Wages' },
          { c: P.other,        l: 'Other income' },
          { c: P.ss,           l: 'Social Sec.' },
          { c: P.pension,      l: 'Pension' },
          { c: P.account401k,  l: '401(k) w/d' },
          { c: P.accountTax,   l: 'Taxable w/d' },
          { c: P.accountRoth,  l: 'Roth w/d' },
          { c: P.spend,        l: 'Spending' },
          { c: P.tax,          l: 'Federal tax' },
          { c: P.spendBump,    l: '◆ Bump year' },
        ]} />
        <window.CashFlowBars rows={rows} hoverAge={hoverAge} setHoverAge={setHoverAge} />
      </Card>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px',
                    gap: 18, marginTop: 18 }}>
        <Card>
          <CardHeader eyebrow="ASSETS — what you have"
            title="Net worth over time" accent={P.account401k}
            right={
              <div style={{ display: 'flex', gap: 8 }}>
                <Chip small label={`Return · ${(state.returnRate*100).toFixed(1)}%`}
                      onClick={openFromChip('growth')} />
                <Chip small label={`Inflation · ${(state.inflation*100).toFixed(1)}%`}
                      onClick={openFromChip('growth')} />
              </div>
            } />
          <Legend items={[
            { c: P.account401k, l: '401(k) / IRA' },
            { c: P.accountTax,  l: 'Taxable brokerage' },
            { c: P.accountRoth, l: 'Roth' },
            { c: P.accountCash, l: 'Cash / bank' },
          ]} />
          <window.ProjectionChart rows={rows} hoverAge={hoverAge}
            setHoverAge={setHoverAge} retireAge={Math.min(state.retireAgeP1, state.retireAgeP2 - state.spouseAgeOffset)}
            depleted={result.depleted} />
        </Card>

        <Card>
          <CardHeader eyebrow="THIS YEAR" title={
            hoverRow ? `Age ${hoverRow.age} · ${hoverRow.year}`
                     : `Age ${state.retireAgeP1} · projected`
          } accent={P.spend} />
          <YearDetail row={hoverRow || atRetire} brackets={result.brackets} />
        </Card>
      </div>

      {showIncomeEditor && (
        <IncomeEditor state={state} update={update}
          onClose={() => setShowIncomeEditor(false)} rows={rows} />
      )}

      {openPanel && (
        <PanelHost id={openPanel.id} anchor={openPanel.anchor}
          state={state} update={update} onClose={() => setOpenPanel(null)} />
      )}

      <footer style={{ marginTop: 36, fontSize: 11, color: P.inkSofter,
                       fontFamily: 'JetBrains Mono, monospace',
                       letterSpacing: '0.04em' }}>
        2025 federal brackets · standard deduction · SS provisional-income rules ·
        RMD age 73 · simplified, not tax advice
      </footer>
    </div>
  );
}

function Card({ children }) {
  return (
    <section style={{
      background: 'linear-gradient(180deg, rgba(20,34,28,0.7), rgba(15,28,24,0.7))',
      border: `1px solid ${window.PALETTE.borderSoft}`,
      borderRadius: 6, padding: '18px 20px 22px',
    }}>{children}</section>
  );
}

function CardHeader({ eyebrow, title, right, accent }) {
  const P = window.PALETTE;
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between',
                  alignItems: 'flex-end', marginBottom: 14, gap: 12 }}>
      <div>
        <div style={{ fontSize: 10, letterSpacing: '0.2em', whiteSpace: 'nowrap',
                      color: accent || P.account401k, fontWeight: 600 }}>
          {eyebrow}
        </div>
        <div style={{ fontSize: 18, marginTop: 4, fontWeight: 500,
                      letterSpacing: '-0.01em' }}>{title}</div>
      </div>
      {right}
    </div>
  );
}

function Legend({ items }) {
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14, marginBottom: 8 }}>
      {items.map((i, k) => (
        <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ width: 10, height: 10, background: i.c,
                         border: i.border || 'none', display: 'inline-block' }} />
          <span style={{ fontSize: 10.5, letterSpacing: '0.04em',
                         color: window.PALETTE.inkSoft,
                         fontFamily: 'Inter Tight, sans-serif' }}>{i.l}</span>
        </div>
      ))}
    </div>
  );
}

function Kpi({ label, value, sub, chip, onClick, accent }) {
  const P = window.PALETTE;
  return (
    <button onClick={onClick} disabled={!chip}
      style={{
        background: 'rgba(15,28,24,0.92)', border: 'none',
        padding: '16px 18px', textAlign: 'left',
        cursor: chip ? 'pointer' : 'default',
        position: 'relative', transition: 'background 160ms',
        color: 'inherit', fontFamily: 'inherit',
      }}
      onMouseEnter={e => chip && (e.currentTarget.style.background = 'rgba(20,38,30,0.95)')}
      onMouseLeave={e => chip && (e.currentTarget.style.background = 'rgba(15,28,24,0.92)')}>
      <div style={{ fontSize: 10, letterSpacing: '0.18em', fontWeight: 600,
                    color: P.inkSoft, textTransform: 'uppercase' }}>{label}</div>
      <div style={{ fontSize: 24, marginTop: 8, fontWeight: 500,
                    letterSpacing: '-0.01em',
                    fontFamily: 'JetBrains Mono, monospace',
                    color: accent || P.ink }}>{value}</div>
      <div style={{ fontSize: 11, marginTop: 4, color: P.inkSofter }}>{sub}</div>
      {chip && (
        <div style={{ position: 'absolute', right: 10, top: 12,
                      fontSize: 9, color: P.account401k,
                      letterSpacing: '0.1em', fontWeight: 600 }}>EDIT ↗</div>
      )}
    </button>
  );
}

function Chip({ label, onClick, small }) {
  const P = window.PALETTE;
  const [hover, setHover] = useState(false);
  return (
    <button onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        padding: small ? '4px 10px' : '6px 12px',
        background: hover ? 'rgba(63,167,107,0.18)' : 'rgba(63,167,107,0.08)',
        border: '1px solid rgba(63,167,107,0.35)',
        borderRadius: 999, fontSize: small ? 11 : 12,
        color: P.ink, fontFamily: 'Inter Tight, sans-serif',
        cursor: 'pointer', transition: 'all 140ms', letterSpacing: '0.01em',
      }}>
      {label}
      <span style={{ fontSize: 9, color: P.account401k,
                     letterSpacing: '0.1em' }}>▾</span>
    </button>
  );
}

function YearDetail({ row, brackets }) {
  const P = window.PALETTE;
  if (!row) return null;
  return (
    <div>
      <window.BracketViz row={row} brackets={brackets} />
      <div style={{ marginTop: 12, display: 'grid', gap: 6 }}>
        <SectionLabel label="INCOME" color={P.wages} />
        <Row k="Wages"            v={window.fmtFull(row.wages)} />
        <Row k="Other income"     v={window.fmtFull(row.other)} />
        <Row k="Social Security"  v={window.fmtFull(row.ss)} />
        <Row k="Pension"          v={window.fmtFull(row.pension)} />
        <Row k="401(k) w/d"       v={window.fmtFull(row.w401k)}
             sub={row.rmd > 0 ? `RMD floor: ${window.fmt(row.rmd)}` : (row.ruleOf55Active ? 'unlocked via Rule of 55' : (row.canTap401k ? null : 'locked until 59½'))}/>
        <Row k="Roth w/d"         v={window.fmtFull(row.wRoth)} />
        <Row k="Taxable w/d"      v={window.fmtFull(row.wTax)} />
        <Row k="From cash"        v={window.fmtFull(row.fromCash)} />

        <Divider />
        <SectionLabel label="EXPENSES" color={P.spend} />
        <Row k="Baseline spend"   v={window.fmtFull(row.baselineSpend)} />
        <Row k="Recurring"        v={window.fmtFull(row.recurringTotal)} />
        <Row k={`Extra bump${row.overrideLabel ? ` · ${row.overrideLabel}` : ''}`}
             v={window.fmtFull(row.overrideExtra)} accent={P.spendBump}/>
        {row.rothConv > 0 && (
          <Row k="Roth conversion" v={window.fmtFull(row.rothConv)}
               sub="401(k) → Roth (taxable)" accent={P.accountTax}/>
        )}
        {row.w401kRMD > 0 && (
          <Row k="⚠ RMD (forced)" v={window.fmtFull(row.w401kRMD)}
               sub="required minimum distribution" accent={P.danger}/>
        )}
        <Row k="Federal tax"      v={window.fmtFull(row.fedTax)}
             sub={`marginal ${(row.marginal*100).toFixed(0)}%`} accent={P.tax}/>

        <Divider />
        <Row k="Net spendable"    v={window.fmtFull(row.netSpend)} accent={P.good} big/>
        <Row k="Ending balance"   v={window.fmtFull(row.totalAssets)} accent={P.account401k} big />
        {row.shortfall > 0 && (
          <Row k="⚠ Shortfall"    v={window.fmtFull(row.shortfall)} accent={P.danger} />
        )}
      </div>
    </div>
  );
}
function SectionLabel({ label, color }) {
  return <div style={{ fontSize: 9, letterSpacing: '0.2em', fontWeight: 600,
                       color: color, marginTop: 4 }}>{label}</div>;
}
function Row({ k, v, sub, accent, big }) {
  const P = window.PALETTE;
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between',
                  alignItems: 'baseline', padding: '2px 0' }}>
      <span style={{ fontSize: 12, color: P.inkSoft }}>{k}</span>
      <div style={{ textAlign: 'right' }}>
        <div style={{ fontFamily: 'JetBrains Mono, monospace',
                      fontSize: big ? 14 : 12,
                      color: accent || P.ink }}>{v}</div>
        {sub && <div style={{ fontSize: 9.5, color: P.inkSofter,
                              fontFamily: 'JetBrains Mono, monospace' }}>{sub}</div>}
      </div>
    </div>
  );
}
function Divider() {
  return <div style={{ height: 1, background: 'rgba(255,255,255,0.06)', margin: '6px 0' }} />;
}

// --- Spend bumps panel (with labels) ---
function SpendPanel({ state, update }) {
  const P = window.PALETTE;
  const [draftAge, setDraftAge] = useState(state.retireAgeP1 + 2);
  const [draftAmt, setDraftAmt] = useState(20000);
  const [draftLabel, setDraftLabel] = useState('');
  const overrides = state.spendOverrides || {};
  const sortedAges = Object.keys(overrides).map(Number).sort((a,b) => a-b);
  // normalize: legacy number  vs new {amount,label}
  const getBump = (age) => {
    const v = overrides[age];
    if (v == null) return { amount: 0, label: '' };
    if (typeof v === 'number') return { amount: v, label: '' };
    return { amount: v.amount || 0, label: v.label || '' };
  };
  const presets = [
    { label: 'Vacation',  amount: 12000 },
    { label: 'New car',   amount: 35000 },
    { label: 'Wedding',   amount: 50000 },
    { label: 'Home reno', amount: 60000 },
    { label: 'Medical',   amount: 25000 },
  ];
  const setOv = (age, amount, label) => {
    const next = { ...overrides };
    if (amount > 0) next[age] = { amount, label: label || '' };
    else delete next[age];
    update({ spendOverrides: next });
  };
  const inputBox = {
    width: 50, background: 'rgba(255,255,255,0.04)',
    border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: 4, padding: '4px 6px',
    color: P.ink, fontFamily: 'JetBrains Mono, monospace',
    fontSize: 11, textAlign: 'center', outline: 'none',
  };
  const amtBox = { ...inputBox, width: 80, textAlign: 'right' };
  const labelBox = { ...inputBox, width: 'auto', flex: 1, textAlign: 'left',
                     fontFamily: 'Inter Tight, sans-serif', fontSize: 12 };
  return (
    <>
      <window.NumberRow label="Baseline spend (today's $)"
        value={state.desiredSpend}
        onChange={v => update({ desiredSpend: v })} step={1000} />
      <window.SliderRow label="P1 retire at age" value={state.retireAgeP1}
        min={state.currentAge} max={75} step={1}
        onChange={v => update({ retireAgeP1: v })} format={v => v} />
      <window.SliderRow label="P2 retire at age" value={state.retireAgeP2}
        min={Math.max(50, state.currentAge + state.spouseAgeOffset)} max={75} step={1}
        onChange={v => update({ retireAgeP2: v })} format={v => v} />
      <div style={{ marginTop: 14, marginBottom: 8,
                    fontSize: 10, letterSpacing: '0.16em',
                    color: P.spendBump, fontWeight: 600 }}>
        ONE-OFF EXTRA SPEND
      </div>
      {sortedAges.length === 0 && (
        <div style={{ fontSize: 11, color: P.inkSofter, padding: '6px 0 10px' }}>
          No bumps yet. Add a year below.
        </div>
      )}
      {sortedAges.map(age => {
        const b = getBump(age);
        return (
        <div key={age} style={{ display: 'flex', alignItems: 'center',
                                gap: 6, padding: '4px 0',
                                borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
          <input type="number" value={age} style={inputBox}
            onChange={e => {
              const newAge = parseInt(e.target.value, 10);
              if (!newAge || newAge === age) return;
              const next = { ...overrides };
              next[newAge] = next[age]; delete next[age];
              update({ spendOverrides: next });
            }} />
          <span style={{ fontSize: 10, color: P.inkSofter }}>age</span>
          <input value={b.label} placeholder="label" style={labelBox}
            onChange={e => setOv(age, b.amount, e.target.value)} />
          <span style={{ fontSize: 11, color: P.spendBump,
                         fontFamily: 'JetBrains Mono, monospace' }}>+$</span>
          <input type="number" value={b.amount} style={amtBox}
            onChange={e => setOv(age, parseFloat(e.target.value) || 0, b.label)} />
          <button onClick={() => setOv(age, 0)}
            style={{ border: 'none', background: 'transparent', cursor: 'pointer',
                     color: P.inkSofter, padding: '0 4px', fontSize: 14 }}
            onMouseEnter={e => e.currentTarget.style.color = P.danger}
            onMouseLeave={e => e.currentTarget.style.color = P.inkSofter}>×</button>
        </div>
      );})}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6,
                    marginTop: 10, padding: '6px 0' }}>
        <input type="number" value={draftAge} style={{...inputBox,
            background: 'rgba(242,169,60,0.08)',
            border: '1px dashed rgba(242,169,60,0.5)' }}
          onChange={e => setDraftAge(parseInt(e.target.value, 10) || 0)} />
        <span style={{ fontSize: 10, color: P.inkSofter }}>age</span>
        <input value={draftLabel} placeholder="label (optional)"
          style={{...labelBox,
            background: 'rgba(242,169,60,0.08)',
            border: '1px dashed rgba(242,169,60,0.5)' }}
          onChange={e => setDraftLabel(e.target.value)} />
        <span style={{ fontSize: 11, color: P.spendBump,
                       fontFamily: 'JetBrains Mono, monospace' }}>+$</span>
        <input type="number" value={draftAmt} style={{...amtBox,
            background: 'rgba(242,169,60,0.08)',
            border: '1px dashed rgba(242,169,60,0.5)' }}
          onChange={e => setDraftAmt(parseFloat(e.target.value) || 0)} />
        <button onClick={() => {
            if (draftAge >= state.currentAge && draftAge <= state.endAge && draftAmt > 0) {
              setOv(draftAge, draftAmt, draftLabel);
              setDraftLabel('');
            }
          }}
          style={{ border: '1px solid rgba(242,169,60,0.55)',
                   background: 'rgba(242,169,60,0.2)',
                   borderRadius: 4, padding: '4px 10px', cursor: 'pointer',
                   color: P.spendBump, fontSize: 11, fontWeight: 600,
                   letterSpacing: '0.04em', fontFamily: 'Inter Tight, sans-serif' }}>
          ADD
        </button>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginTop: 10 }}>
        {presets.map(p => (
          <button key={p.label} onClick={() => { setDraftAmt(p.amount); setDraftLabel(p.label); }}
            style={{ border: '1px solid rgba(255,255,255,0.1)',
                     background: 'rgba(255,255,255,0.03)',
                     borderRadius: 999, padding: '3px 9px', cursor: 'pointer',
                     color: P.inkSoft, fontSize: 10,
                     fontFamily: 'Inter Tight, sans-serif' }}>
            {p.label} · ${p.amount.toLocaleString()}
          </button>
        ))}
      </div>
    </>
  );
}

// --- Roth conversion panel ---
function RothPanel({ state, update }) {
  const P = window.PALETTE;
  const conv = state.rothConversions || {};
  const ages = Object.keys(conv).map(Number).sort((a,b) => a-b);
  const [draftAge, setDraftAge] = useState(state.retireAgeP1);
  const [draftAmt, setDraftAmt] = useState(30000);
  const setConv = (age, amt) => {
    const next = { ...conv };
    if (amt > 0) next[age] = amt; else delete next[age];
    update({ rothConversions: next });
  };
  const fillBracket = (cap) => {
    // suggest filling 12% bracket headroom each year between retirement and SS start
    const next = { ...conv };
    for (let a = state.retireAgeP1; a < state.ssStartAge; a++) {
      next[a] = cap;
    }
    update({ rothConversions: next });
  };
  const inputBox = {
    width: 60, background: 'rgba(255,255,255,0.04)',
    border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: 4, padding: '4px 6px',
    color: P.ink, fontFamily: 'JetBrains Mono, monospace',
    fontSize: 11, textAlign: 'center', outline: 'none',
  };
  const amtBox = { ...inputBox, width: 100, textAlign: 'right' };
  return (
    <>
      <div style={{ fontSize: 11, color: P.inkSoft, marginBottom: 10, lineHeight: 1.5 }}>
        Move $X from 401(k) to Roth in a given year. Counts as ordinary income that year,
        but grows tax-free forever after. Best done in low-income gap years
        (post-retirement, pre-Social Security).
      </div>
      {ages.length === 0 && (
        <div style={{ fontSize: 11, color: P.inkSofter, padding: '6px 0 10px' }}>
          No conversions scheduled.
        </div>
      )}
      {ages.map(age => (
        <div key={age} style={{ display: 'flex', alignItems: 'center',
                                gap: 6, padding: '4px 0',
                                borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
          <input type="number" value={age} style={inputBox}
            onChange={e => {
              const newAge = parseInt(e.target.value, 10);
              if (!newAge || newAge === age) return;
              const next = { ...conv };
              next[newAge] = next[age]; delete next[age];
              update({ rothConversions: next });
            }} />
          <span style={{ fontSize: 10, color: P.inkSofter, flex: 1 }}>age</span>
          <span style={{ fontSize: 11, color: P.accountTax,
                         fontFamily: 'JetBrains Mono, monospace' }}>$</span>
          <input type="number" value={conv[age]} style={amtBox}
            onChange={e => setConv(age, parseFloat(e.target.value) || 0)} />
          <button onClick={() => setConv(age, 0)}
            style={{ border: 'none', background: 'transparent', cursor: 'pointer',
                     color: P.inkSofter, padding: '0 4px', fontSize: 14 }}
            onMouseEnter={e => e.currentTarget.style.color = P.danger}
            onMouseLeave={e => e.currentTarget.style.color = P.inkSofter}>×</button>
        </div>
      ))}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6,
                    marginTop: 10, padding: '6px 0' }}>
        <input type="number" value={draftAge} style={{...inputBox,
            background: 'rgba(124,154,210,0.10)',
            border: '1px dashed rgba(124,154,210,0.5)' }}
          onChange={e => setDraftAge(parseInt(e.target.value, 10) || 0)} />
        <span style={{ fontSize: 10, color: P.inkSofter, flex: 1 }}>age</span>
        <span style={{ fontSize: 11, color: P.accountTax,
                       fontFamily: 'JetBrains Mono, monospace' }}>$</span>
        <input type="number" value={draftAmt} style={{...amtBox,
            background: 'rgba(124,154,210,0.10)',
            border: '1px dashed rgba(124,154,210,0.5)' }}
          onChange={e => setDraftAmt(parseFloat(e.target.value) || 0)} />
        <button onClick={() => {
            if (draftAge >= state.currentAge && draftAge <= state.endAge && draftAmt > 0)
              setConv(draftAge, draftAmt);
          }}
          style={{ border: '1px solid rgba(124,154,210,0.55)',
                   background: 'rgba(124,154,210,0.18)',
                   borderRadius: 4, padding: '4px 10px', cursor: 'pointer',
                   color: P.accountTax, fontSize: 11, fontWeight: 600,
                   letterSpacing: '0.04em', fontFamily: 'Inter Tight, sans-serif' }}>
          ADD
        </button>
      </div>
      <div style={{ marginTop: 12, fontSize: 10, letterSpacing: '0.16em',
                    color: P.inkSofter, fontWeight: 600 }}>
        STRATEGY PRESETS
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginTop: 6 }}>
        {[
          { label: 'Fill 12% bracket', amount: 50000 },
          { label: 'Fill 22% bracket', amount: 100000 },
          { label: 'Aggressive', amount: 150000 },
        ].map(p => (
          <button key={p.label} onClick={() => fillBracket(p.amount)}
            style={{ border: '1px solid rgba(124,154,210,0.3)',
                     background: 'rgba(124,154,210,0.08)',
                     borderRadius: 999, padding: '3px 9px', cursor: 'pointer',
                     color: P.accountTax, fontSize: 10,
                     fontFamily: 'Inter Tight, sans-serif' }}>
            {p.label} · ${(p.amount/1000).toFixed(0)}k·yr
          </button>
        ))}
        <button onClick={() => update({ rothConversions: {} })}
          style={{ border: '1px solid rgba(255,255,255,0.1)',
                   background: 'transparent',
                   borderRadius: 999, padding: '3px 9px', cursor: 'pointer',
                   color: P.inkSofter, fontSize: 10,
                   fontFamily: 'Inter Tight, sans-serif' }}>
          Clear all
        </button>
      </div>
      <div style={{ marginTop: 10, padding: 8,
                    background: 'rgba(124,154,210,0.06)',
                    border: '1px solid rgba(124,154,210,0.18)',
                    borderRadius: 4, fontSize: 10.5, color: P.inkSoft,
                    lineHeight: 1.5 }}>
        Strategy presets fill every year from age {state.retireAgeP1} (P1 retire)
        to {state.ssStartAge} (SS start) with the same amount.
      </div>
    </>
  );
}

// --- Recurring expenses panel (mortgage, car, custom) ---
function RecurringPanel({ state, update }) {
  const P = window.PALETTE;
  const items = state.recurringExpenses || [];
  const [draft, setDraft] = useState({ label: '', amount: 0, startAge: state.currentAge, endAge: state.endAge });

  const setItems = (next) => update({ recurringExpenses: next });
  const updateItem = (i, patch) => {
    const next = items.map((it, idx) => idx === i ? { ...it, ...patch } : it);
    setItems(next);
  };
  const removeItem = (i) => setItems(items.filter((_, idx) => idx !== i));
  const addPreset = (label, amount) => {
    setItems([...items, { label, amount, startAge: state.currentAge, endAge: state.endAge }]);
  };

  const inputBase = {
    background: 'rgba(255,255,255,0.04)',
    border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: 4, padding: '4px 6px',
    color: P.ink, fontFamily: 'JetBrains Mono, monospace',
    fontSize: 11, outline: 'none',
  };

  return (
    <>
      <div style={{ fontSize: 11, color: P.inkSoft, marginBottom: 10 }}>
        Recurring expenses run every year between start and end ages. Examples:
        mortgage, car payment, insurance.
      </div>

      {items.length === 0 && (
        <div style={{ fontSize: 11, color: P.inkSofter, padding: '6px 0 10px' }}>
          No recurring expenses. Add one below.
        </div>
      )}

      {items.map((it, i) => (
        <div key={i} style={{ display: 'grid',
            gridTemplateColumns: '1fr 80px 44px 44px 18px',
            gap: 6, alignItems: 'center', padding: '5px 0',
            borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
          <input value={it.label} placeholder="Label"
            onChange={e => updateItem(i, { label: e.target.value })}
            style={{ ...inputBase, fontFamily: 'Inter Tight, sans-serif',
                     fontSize: 12, textAlign: 'left' }} />
          <input type="number" value={it.amount}
            onChange={e => updateItem(i, { amount: parseFloat(e.target.value) || 0 })}
            style={{ ...inputBase, textAlign: 'right' }} />
          <input type="number" value={it.startAge}
            onChange={e => updateItem(i, { startAge: parseInt(e.target.value, 10) || 0 })}
            style={{ ...inputBase, textAlign: 'center' }} title="Start age"/>
          <input type="number" value={it.endAge}
            onChange={e => updateItem(i, { endAge: parseInt(e.target.value, 10) || 0 })}
            style={{ ...inputBase, textAlign: 'center' }} title="End age"/>
          <button onClick={() => removeItem(i)}
            style={{ border: 'none', background: 'transparent', cursor: 'pointer',
                     color: P.inkSofter, fontSize: 14, padding: 0 }}
            onMouseEnter={e => e.currentTarget.style.color = P.danger}
            onMouseLeave={e => e.currentTarget.style.color = P.inkSofter}>×</button>
        </div>
      ))}

      <div style={{ display: 'flex', gap: 6, fontSize: 9,
                    color: P.inkSofter, padding: '4px 0',
                    fontFamily: 'Inter Tight, sans-serif',
                    letterSpacing: '0.08em' }}>
        <span style={{ flex: 1 }}>LABEL</span>
        <span style={{ width: 80, textAlign: 'right' }}>$/YR</span>
        <span style={{ width: 44, textAlign: 'center' }}>START</span>
        <span style={{ width: 44, textAlign: 'center' }}>END</span>
        <span style={{ width: 18 }}/>
      </div>

      <div style={{ display: 'grid',
            gridTemplateColumns: '1fr 80px 44px 44px 60px',
            gap: 6, alignItems: 'center', marginTop: 8 }}>
        <input value={draft.label} placeholder="New expense"
          onChange={e => setDraft({ ...draft, label: e.target.value })}
          style={{ ...inputBase, fontFamily: 'Inter Tight, sans-serif',
                   fontSize: 12,
                   background: 'rgba(242,201,76,0.08)',
                   border: '1px dashed rgba(242,201,76,0.4)' }} />
        <input type="number" value={draft.amount}
          onChange={e => setDraft({ ...draft, amount: parseFloat(e.target.value) || 0 })}
          style={{ ...inputBase, textAlign: 'right',
                   background: 'rgba(242,201,76,0.08)',
                   border: '1px dashed rgba(242,201,76,0.4)' }} />
        <input type="number" value={draft.startAge}
          onChange={e => setDraft({ ...draft, startAge: parseInt(e.target.value, 10) || 0 })}
          style={{ ...inputBase, textAlign: 'center',
                   background: 'rgba(242,201,76,0.08)',
                   border: '1px dashed rgba(242,201,76,0.4)' }} />
        <input type="number" value={draft.endAge}
          onChange={e => setDraft({ ...draft, endAge: parseInt(e.target.value, 10) || 0 })}
          style={{ ...inputBase, textAlign: 'center',
                   background: 'rgba(242,201,76,0.08)',
                   border: '1px dashed rgba(242,201,76,0.4)' }} />
        <button onClick={() => {
            if (draft.label && draft.amount > 0) {
              setItems([...items, draft]);
              setDraft({ label: '', amount: 0, startAge: state.currentAge, endAge: state.endAge });
            }
          }}
          style={{ border: '1px solid rgba(242,201,76,0.5)',
                   background: 'rgba(242,201,76,0.2)',
                   borderRadius: 4, padding: '4px 8px', cursor: 'pointer',
                   color: P.spend, fontSize: 11, fontWeight: 600,
                   letterSpacing: '0.04em', fontFamily: 'Inter Tight, sans-serif' }}>
          ADD
        </button>
      </div>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginTop: 12 }}>
        {[
          { l: 'Mortgage',  a: 28800 },
          { l: 'Car',       a: 7200 },
          { l: 'Insurance', a: 3600 },
          { l: 'HOA',       a: 4800 },
          { l: 'Travel',    a: 8000 },
        ].map(p => (
          <button key={p.l} onClick={() => addPreset(p.l, p.a)}
            style={{ border: '1px solid rgba(255,255,255,0.1)',
                     background: 'rgba(255,255,255,0.03)',
                     borderRadius: 999, padding: '3px 9px', cursor: 'pointer',
                     color: P.inkSoft, fontSize: 10,
                     fontFamily: 'Inter Tight, sans-serif' }}>
            + {p.l} · ${p.a.toLocaleString()}/yr
          </button>
        ))}
      </div>
    </>
  );
}

function IncomeEditor({ state, update, onClose, rows }) {
  const P = window.PALETTE;
  const overrides = state.incomeOverrides || {};
  const setOv = (age, patch) => {
    const next = { ...overrides };
    const cur = next[age] || {};
    const merged = { ...cur, ...patch };
    // Clean up empty entries
    if (merged.wagesP1 == null && merged.wagesP2 == null && merged.other == null) {
      delete next[age];
    } else {
      next[age] = merged;
    }
    update({ incomeOverrides: next });
  };
  const clearAge = (age) => {
    const next = { ...overrides };
    delete next[age];
    update({ incomeOverrides: next });
  };
  const clearAll = () => update({ incomeOverrides: {} });

  // Build year list — only working-eligible years (someone could plausibly be working)
  const years = rows.filter(r => r.age <= Math.max(state.retireAgeP1, state.retireAgeP2 - state.spouseAgeOffset) + 5);

  const cellInput = {
    width: '100%', background: 'rgba(255,255,255,0.04)',
    border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: 3, padding: '4px 6px',
    color: P.ink, fontFamily: 'JetBrains Mono, monospace',
    fontSize: 11, textAlign: 'right', outline: 'none',
    boxSizing: 'border-box',
  };
  const headerCell = {
    fontSize: 9.5, letterSpacing: '0.14em', fontWeight: 600,
    color: P.inkSoft, padding: '8px 6px',
    fontFamily: 'Inter Tight, sans-serif',
    borderBottom: '1px solid rgba(255,255,255,0.08)',
  };

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 9999,
                  background: 'rgba(6,10,8,0.85)',
                  backdropFilter: 'blur(8px)',
                  display: 'flex', alignItems: 'flex-start', justifyContent: 'center',
                  padding: '40px 24px', overflowY: 'auto' }}
         onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div style={{
        width: '100%', maxWidth: 920,
        background: 'linear-gradient(180deg, #14241D, #0E1B16)',
        border: `1px solid ${P.borderAccent}`,
        borderRadius: 6, padding: '24px 28px 28px',
        color: P.ink, fontFamily: 'Inter Tight, sans-serif',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between',
                      alignItems: 'flex-start', marginBottom: 18, gap: 12 }}>
          <div>
            <div style={{ fontSize: 10, letterSpacing: '0.22em',
                          color: P.account401k, fontWeight: 600 }}>
              INCOME — FINE-TUNE BY YEAR
            </div>
            <h2 style={{ margin: '6px 0 0', fontSize: 24, fontWeight: 500,
                         letterSpacing: '-0.01em' }}>
              Year-by-year wages & other income
            </h2>
            <p style={{ margin: '6px 0 0', fontSize: 12, color: P.inkSoft,
                        maxWidth: 620, lineHeight: 1.5 }}>
              Defaults come from the Income panel and stop at each spouse's retirement age.
              Override any cell to model part-time work, severance, sabbaticals, gap years,
              or one-spouse-keeps-working scenarios. All values are in today's dollars; the
              engine inflates them automatically.
            </p>
          </div>
          <button onClick={onClose}
            style={{ border: '1px solid rgba(255,255,255,0.15)',
                     background: 'rgba(255,255,255,0.04)',
                     color: P.ink, borderRadius: 4, padding: '6px 14px',
                     cursor: 'pointer', fontSize: 12,
                     fontFamily: 'Inter Tight, sans-serif',
                     letterSpacing: '0.04em' }}>
            CLOSE ✕
          </button>
        </div>

        <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
          <button onClick={clearAll}
            style={{ border: '1px solid rgba(224,88,76,0.4)',
                     background: 'rgba(224,88,76,0.1)',
                     color: P.danger, borderRadius: 4,
                     padding: '5px 12px', cursor: 'pointer',
                     fontSize: 11, letterSpacing: '0.04em',
                     fontFamily: 'Inter Tight, sans-serif' }}>
            CLEAR ALL OVERRIDES
          </button>
          <button onClick={() => {
              // Quick preset: P1 part-time after retire (50% wages for 3 years)
              const next = { ...overrides };
              for (let i = 0; i < 3; i++) {
                const age = state.retireAgeP1 + i;
                next[age] = { ...(next[age] || {}), wagesP1: state.workIncomeP1 * 0.5 };
              }
              update({ incomeOverrides: next });
            }}
            style={{ border: '1px solid rgba(63,167,107,0.4)',
                     background: 'rgba(63,167,107,0.08)',
                     color: P.account401k, borderRadius: 4,
                     padding: '5px 12px', cursor: 'pointer',
                     fontSize: 11, letterSpacing: '0.04em',
                     fontFamily: 'Inter Tight, sans-serif' }}>
            + P1 PART-TIME 3 YRS @ 50%
          </button>
          <button onClick={() => {
              const next = { ...overrides };
              for (let i = 0; i < 3; i++) {
                const age = state.retireAgeP2 - state.spouseAgeOffset + i;
                next[age] = { ...(next[age] || {}), wagesP2: state.workIncomeP2 * 0.5 };
              }
              update({ incomeOverrides: next });
            }}
            style={{ border: '1px solid rgba(63,167,107,0.4)',
                     background: 'rgba(63,167,107,0.08)',
                     color: P.account401k, borderRadius: 4,
                     padding: '5px 12px', cursor: 'pointer',
                     fontSize: 11, letterSpacing: '0.04em',
                     fontFamily: 'Inter Tight, sans-serif' }}>
            + P2 PART-TIME 3 YRS @ 50%
          </button>
        </div>

        <div style={{ maxHeight: '60vh', overflowY: 'auto',
                      border: '1px solid rgba(255,255,255,0.06)', borderRadius: 4 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse',
                          fontFamily: 'JetBrains Mono, monospace' }}>
            <thead style={{ position: 'sticky', top: 0,
                            background: '#14241D', zIndex: 1 }}>
              <tr>
                <th style={{ ...headerCell, textAlign: 'left', width: 60 }}>AGE</th>
                <th style={{ ...headerCell, textAlign: 'left', width: 70 }}>YEAR</th>
                <th style={{ ...headerCell, textAlign: 'left', width: 90 }}>STATUS</th>
                <th style={{ ...headerCell, textAlign: 'right' }}>P1 WAGES</th>
                <th style={{ ...headerCell, textAlign: 'right' }}>P2 WAGES</th>
                <th style={{ ...headerCell, textAlign: 'right' }}>OTHER</th>
                <th style={{ ...headerCell, textAlign: 'right', width: 110 }}>TOTAL</th>
                <th style={{ ...headerCell, textAlign: 'center', width: 36 }}/>
              </tr>
            </thead>
            <tbody>
              {years.map(r => {
                const ov = overrides[r.age] || {};
                const hasOv = Object.keys(ov).length > 0;
                const p1Default = r.p1Working ? state.workIncomeP1 : 0;
                const p2Default = r.p2Working ? state.workIncomeP2 : 0;
                const otherDefault = state.otherIncome;
                const p1Val = ov.wagesP1 != null ? ov.wagesP1 : p1Default;
                const p2Val = ov.wagesP2 != null ? ov.wagesP2 : p2Default;
                const otherVal = ov.other != null ? ov.other : otherDefault;
                const total = p1Val + p2Val + otherVal;
                const status = (r.p1Working && r.p2Working) ? 'Both work'
                             : r.p1Working ? 'P1 only'
                             : r.p2Working ? 'P2 only'
                             : 'Retired';
                const statusColor = (r.p1Working && r.p2Working) ? P.wages
                                  : (r.p1Working || r.p2Working) ? P.other
                                  : P.inkSofter;
                const cellStyle = (overridden) => ({
                  ...cellInput,
                  background: overridden ? 'rgba(63,167,107,0.12)' : cellInput.background,
                  borderColor: overridden ? 'rgba(63,167,107,0.4)' : cellInput.border,
                });
                return (
                  <tr key={r.age} style={{
                      borderBottom: '1px solid rgba(255,255,255,0.04)',
                      background: hasOv ? 'rgba(63,167,107,0.04)' : 'transparent',
                  }}>
                    <td style={{ padding: '6px 8px', fontSize: 12, color: P.ink }}>{r.age}</td>
                    <td style={{ padding: '6px 8px', fontSize: 12, color: P.inkSofter }}>{r.year}</td>
                    <td style={{ padding: '6px 8px', fontSize: 11,
                                 fontFamily: 'Inter Tight, sans-serif',
                                 color: statusColor }}>{status}</td>
                    <td style={{ padding: '4px 6px' }}>
                      <input type="number" value={Math.round(p1Val)}
                        onChange={e => setOv(r.age, { wagesP1: parseFloat(e.target.value) || 0 })}
                        style={cellStyle(ov.wagesP1 != null)} />
                    </td>
                    <td style={{ padding: '4px 6px' }}>
                      <input type="number" value={Math.round(p2Val)}
                        onChange={e => setOv(r.age, { wagesP2: parseFloat(e.target.value) || 0 })}
                        style={cellStyle(ov.wagesP2 != null)} />
                    </td>
                    <td style={{ padding: '4px 6px' }}>
                      <input type="number" value={Math.round(otherVal)}
                        onChange={e => setOv(r.age, { other: parseFloat(e.target.value) || 0 })}
                        style={cellStyle(ov.other != null)} />
                    </td>
                    <td style={{ padding: '6px 8px', textAlign: 'right',
                                 fontSize: 12, color: total > 0 ? P.ink : P.inkSofter }}>
                      {total > 0 ? window.fmt(total) : '—'}
                    </td>
                    <td style={{ padding: '4px 6px', textAlign: 'center' }}>
                      {hasOv && (
                        <button onClick={() => clearAge(r.age)}
                          title="Reset to default"
                          style={{ border: 'none', background: 'transparent',
                                   cursor: 'pointer', color: P.inkSofter,
                                   fontSize: 14, padding: 0 }}
                          onMouseEnter={e => e.currentTarget.style.color = P.danger}
                          onMouseLeave={e => e.currentTarget.style.color = P.inkSofter}>
                          ↺
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div style={{ marginTop: 12, fontSize: 11, color: P.inkSofter,
                      display: 'flex', gap: 14, flexWrap: 'wrap' }}>
          <span>Highlighted rows = overridden</span>
          <span>↺ resets a row to its default</span>
          <span>All values in today's dollars</span>
        </div>
      </div>
    </div>
  );
}

function PanelHost({ id, anchor, state, update, onClose }) {
  const P = window.PALETTE;
  const titles = {
    accounts: 'Account balances',
    spend:    'Spending & bumps',
    income:   'Income from work & other',
    recurring:'Recurring expenses',
    growth:   'Growth assumptions',
    ss:       'Social Security',
    pension:  'Pension',
    filing:   'Filing status',
    horizon:  'Time horizon',
    retire:   'Retirement timing',
  };
  const wide = id === 'accounts' || id === 'spend' || id === 'recurring' || id === 'income' || id === 'retire';
  return (
    <window.FloatingPanel title={titles[id] || id} anchor={anchor}
      onClose={onClose} width={wide ? 380 : 320}>
      {id === 'accounts' && (
        <>
          <window.NumberRow label="401(k) / Trad IRA" value={state.balance401k}
            onChange={v => update({ balance401k: v })} step={1000} />
          <window.NumberRow label="Roth IRA" value={state.balanceRoth}
            onChange={v => update({ balanceRoth: v })} step={1000} />
          <window.NumberRow label="Taxable brokerage" value={state.balanceTaxable}
            onChange={v => update({ balanceTaxable: v })} step={1000} />
          <window.NumberRow label="Cash / bank" value={state.balanceCash}
            onChange={v => update({ balanceCash: v })} step={1000} />
          <window.NumberRow label="Annual 401(k) contribution" value={state.contribution401k}
            onChange={v => update({ contribution401k: v })} step={500} />
          <window.NumberRow label="Employer match" value={state.employerMatch}
            onChange={v => update({ employerMatch: v })} step={500} />
        </>
      )}
      {id === 'spend' && <SpendPanel state={state} update={update} />}
      {id === 'roth' && <RothPanel state={state} update={update} />}
      {id === 'recurring' && <RecurringPanel state={state} update={update} />}
      {id === 'income' && (
        <>
          <window.NumberRow label="Person 1 wages (annual)" value={state.workIncomeP1}
            onChange={v => update({ workIncomeP1: v })} step={1000} />
          <window.NumberRow label="Person 2 wages (annual)" value={state.workIncomeP2}
            onChange={v => update({ workIncomeP2: v })} step={1000} />
          <window.NumberRow label="Other income (rental, etc.)" value={state.otherIncome}
            onChange={v => update({ otherIncome: v })} step={500} />
          <div style={{ marginTop: 10, fontSize: 11, color: P.inkSoft, lineHeight: 1.5 }}>
            Wages stop at each spouse's retirement age. Other income runs every year.
            All grow with inflation and are taxed as ordinary income. Use the
            <strong style={{color: P.account401k}}> Fine-tune by year</strong> button on the cash-flow
            chart for year-specific overrides (part-time, severance, gap year).
          </div>
        </>
      )}
      {id === 'retire' && (
        <>
          <window.SliderRow label="Person 1 retire at age" value={state.retireAgeP1}
            min={50} max={75} step={1}
            onChange={v => update({ retireAgeP1: v })} format={v => v} />
          <window.SliderRow label="Person 2 retire at age" value={state.retireAgeP2}
            min={50} max={75} step={1}
            onChange={v => update({ retireAgeP2: v })} format={v => v} />
          <window.SliderRow label="Spouse age vs P1" value={state.spouseAgeOffset}
            min={-15} max={15} step={1}
            onChange={v => update({ spouseAgeOffset: v })}
            format={v => v === 0 ? 'same age' : (v > 0 ? `+${v} (older)` : `${v} (younger)`)} />
          <div style={{ marginTop: 14, marginBottom: 6, fontSize: 10,
                        letterSpacing: '0.16em', color: P.account401k, fontWeight: 600 }}>
            RULE OF 55
          </div>
          <div style={{ fontSize: 11, color: P.inkSoft, lineHeight: 1.5, marginBottom: 8 }}>
            If you separate from your employer in or after the year you turn 55,
            you can withdraw from THAT employer's 401(k) without the 10% early-
            withdrawal penalty. Set the age you separate (leave blank to disable).
          </div>
          <window.SegRow label="Rule of 55 status"
            value={state.ruleOf55Age == null ? 'off' : 'on'}
            options={[{value:'off',label:'Disabled'},{value:'on',label:'Enabled'}]}
            onChange={v => update({ ruleOf55Age: v === 'on' ? Math.max(55, state.retireAgeP1) : null })} />
          {state.ruleOf55Age != null && (
            <window.SliderRow label="Separation age" value={state.ruleOf55Age}
              min={55} max={70} step={1}
              onChange={v => update({ ruleOf55Age: v })} format={v => v} />
          )}
        </>
      )}
      {id === 'growth' && (
        <>
          <window.SliderRow label="Investment return" value={state.returnRate}
            min={0.01} max={0.12} step={0.005}
            onChange={v => update({ returnRate: v })}
            format={v => (v*100).toFixed(1) + '%'} />
          <window.SliderRow label="Inflation" value={state.inflation}
            min={0} max={0.06} step={0.0025}
            onChange={v => update({ inflation: v })}
            format={v => (v*100).toFixed(2) + '%'} />
          <div style={{ marginTop: 10, fontSize: 11, color: P.inkSoft, lineHeight: 1.5 }}>
            Real return ≈ {((state.returnRate - state.inflation)*100).toFixed(1)}%.
          </div>
        </>
      )}
      {id === 'ss' && (
        <>
          <window.NumberRow label="Annual benefit (today's $)" value={state.ssBenefit}
            onChange={v => update({ ssBenefit: v })} step={500} />
          <window.SliderRow label="Claim at age" value={state.ssStartAge}
            min={62} max={70} step={1}
            onChange={v => update({ ssStartAge: v })} format={v => v} />
        </>
      )}
      {id === 'pension' && (
        <window.NumberRow label="Annual pension" value={state.pension}
          onChange={v => update({ pension: v })} step={500} />
      )}
      {id === 'filing' && (
        <window.SegRow label="Filing status" value={state.filing}
          options={[{value:'single',label:'Single'},{value:'mfj',label:'Married/Joint'}]}
          onChange={v => update({ filing: v })} />
      )}
      {id === 'horizon' && (
        <>
          <window.SliderRow label="Current age" value={state.currentAge}
            min={25} max={75} step={1}
            onChange={v => update({
              currentAge: v,
              retireAgeP1: Math.max(v, state.retireAgeP1),
              retireAgeP2: Math.max(v + state.spouseAgeOffset, state.retireAgeP2),
              ssStartAge: Math.max(v, state.ssStartAge),
            })} format={v => v} />
          <window.SliderRow label="Plan through age" value={state.endAge}
            min={75} max={105} step={1}
            onChange={v => update({ endAge: v })} format={v => v} />
        </>
      )}
    </window.FloatingPanel>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
