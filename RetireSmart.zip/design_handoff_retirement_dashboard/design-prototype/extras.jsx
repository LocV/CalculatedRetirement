// extras.jsx — cash-flow bars (income above zero, expenses below) + bracket viz
const { useMemo: _useMemo, useRef: _useRef, useState: _useState, useEffect: _useEffect } = React;

function CashFlowBars({ rows, hoverAge, setHoverAge }) {
  const P = window.PALETTE;
  const wrapRef = _useRef(null);
  const [w, setW] = _useState(960);
  const h = 280;
  const padL = 64, padR = 24, padT = 16, padB = 28;

  _useEffect(() => {
    const obs = new ResizeObserver(entries => {
      for (const e of entries) setW(Math.max(400, e.contentRect.width));
    });
    if (wrapRef.current) obs.observe(wrapRef.current);
    return () => obs.disconnect();
  }, []);

  const innerW = w - padL - padR;
  const innerH = h - padT - padB;

  // Compute income & expense totals per row to find max scale.
  const data = _useMemo(() => rows.map(r => {
    const income = r.wages + r.other + r.ss + r.pension
                 + r.w401k + r.wRoth + r.wTax + r.fromCash;
    const expense = r.targetSpend + r.fedTax;
    return { r, income, expense };
  }), [rows]);

  const maxAbs = _useMemo(() =>
    Math.max(...data.map(d => Math.max(d.income, d.expense)), 1),
    [data]
  );

  const x = (i) => padL + (i / rows.length) * innerW;
  const bw = innerW / rows.length * 0.78;
  // Zero line at vertical midpoint
  const zeroY = padT + innerH / 2;
  const yScale = (innerH / 2) / maxAbs; // px per dollar in either direction

  const ticks = 3;
  const tickVals = Array.from({length: ticks*2+1}, (_, i) => maxAbs * (i - ticks) / ticks);

  const ageTicks = rows.map((r, i) => ({r, i})).filter(({r}) => r.age % 5 === 0);

  return (
    <div ref={wrapRef} style={{ width: '100%' }}>
      <svg width={w} height={h} style={{ display: 'block' }}
           onMouseMove={(e) => {
             const rect = e.currentTarget.getBoundingClientRect();
             const px = e.clientX - rect.left;
             const idx = Math.round(((px - padL) / innerW) * rows.length);
             if (rows[idx]) setHoverAge(rows[idx].age);
           }}
           onMouseLeave={() => setHoverAge(null)}>

        {/* Grid */}
        {tickVals.map((v, i) => {
          const yy = zeroY - v * yScale;
          return (
            <g key={i}>
              <line x1={padL} x2={w-padR} y1={yy} y2={yy}
                    stroke={v === 0 ? 'rgba(255,255,255,0.25)' : 'rgba(255,255,255,0.05)'}
                    strokeWidth={v === 0 ? 1 : 1} />
              <text x={padL-10} y={yy+4} fill="rgba(255,255,255,0.4)"
                    fontSize="10" textAnchor="end" fontFamily="JetBrains Mono, monospace">
                {v === 0 ? '0' : window.fmt(Math.abs(v))}
              </text>
            </g>
          );
        })}

        {/* Bars */}
        {data.map((d, i) => {
          const r = d.r;
          const xi = x(i);
          const isHover = hoverAge === r.age;
          const opac = (hoverAge && !isHover) ? 0.35 : 1;

          // INCOME (above zero) — stack: wages, other, ss, pension,
          // VOLUNTARY 401k, RMD 401k (distinct), wTax, wRoth, fromCash
          const incomeSegs = [
            { v: r.wages,           c: P.wages },
            { v: r.other,           c: P.other },
            { v: r.ss,              c: P.ss },
            { v: r.pension,         c: P.pension },
            { v: r.w401kVoluntary || 0, c: P.account401k },
            { v: r.w401kRMD || 0,   c: '#7A1F18', pattern: true },
            { v: r.wTax,            c: P.accountTax },
            { v: r.wRoth,           c: P.accountRoth },
            { v: r.fromCash,        c: P.accountCash },
          ];
          // EXPENSES (below zero): spend, then Roth-conversion (purple/green hatch),
          // then tax (red) on top
          const expenseSegs = [
            { v: r.targetSpend,    c: P.spend },
            { v: r.rothConv || 0,  c: '#5FBF8F', striped: true },
            { v: r.fedTax,         c: P.tax },
          ];

          let incStack = 0, expStack = 0;
          return (
            <g key={r.age} opacity={opac}>
              {incomeSegs.map((s, si) => {
                if (s.v <= 0) return null;
                const yTop = zeroY - (incStack + s.v) * yScale;
                const yBot = zeroY - incStack * yScale;
                incStack += s.v;
                return <rect key={'i'+si} x={xi} y={yTop} width={bw}
                             height={Math.max(0.5, yBot - yTop)} fill={s.c}
                             stroke={s.pattern ? '#F2C94C' : 'none'}
                             strokeWidth={s.pattern ? 0.6 : 0} />;
              })}
              {expenseSegs.map((s, si) => {
                if (s.v <= 0) return null;
                const yTop = zeroY + expStack * yScale;
                const yBot = zeroY + (expStack + s.v) * yScale;
                expStack += s.v;
                return <rect key={'e'+si} x={xi} y={yTop} width={bw}
                             height={Math.max(0.5, yBot - yTop)} fill={s.c}
                             stroke={s.striped ? '#0A1410' : 'none'}
                             strokeDasharray={s.striped ? '2 2' : ''}
                             strokeWidth={s.striped ? 1 : 0} />;
              })}
              {/* Bump diamond above income */}
              {r.overrideExtra > 0 && (
                <polygon
                  points={`${xi+bw/2},${zeroY - d.income*yScale - 12}
                           ${xi+bw/2+5},${zeroY - d.income*yScale - 7}
                           ${xi+bw/2},${zeroY - d.income*yScale - 2}
                           ${xi+bw/2-5},${zeroY - d.income*yScale - 7}`}
                  fill={P.spendBump} stroke="#0A1410" strokeWidth="0.5" />
              )}
            </g>
          );
        })}

        {/* Age axis at zero line */}
        {ageTicks.map(({r, i}) => (
          <text key={r.age} x={x(i) + bw/2} y={padT+innerH+16}
                fill="rgba(255,255,255,0.5)" fontSize="10"
                textAnchor="middle" fontFamily="JetBrains Mono, monospace">
            {r.age}
          </text>
        ))}

        {/* Income / Expense labels */}
        <text x={w-padR} y={padT+10} fill={P.good} fontSize="9"
              textAnchor="end" fontFamily="Inter Tight, sans-serif"
              letterSpacing="0.14em" fontWeight="600">
          INCOME ▲
        </text>
        <text x={w-padR} y={h-padB+4} fill={P.danger} fontSize="9"
              textAnchor="end" fontFamily="Inter Tight, sans-serif"
              letterSpacing="0.14em" fontWeight="600">
          EXPENSES ▼
        </text>
      </svg>
    </div>
  );
}

function BracketViz({ row, brackets }) {
  const P = window.PALETTE;
  if (!row) return (
    <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12, padding: 16 }}>
      Hover the chart to see this year's tax position.
    </div>
  );
  const w = 320, h = 130;
  const padL = 8, padR = 8, padT = 16, padB = 28;
  const maxX = Math.max(row.taxableIncome * 1.6, brackets[2].upto, 250000);
  const x = v => padL + (v / maxX) * (w - padL - padR);
  // Color by severity per user spec:
  //   ≤12% good (greens), 22% caution (amber), 24% bad (deep amber),
  //   ≥32% very bad (reds, deepening to dark)
  const severityColor = (rate) => {
    if (rate <= 0.10) return '#1F6B47';   // deep green
    if (rate <= 0.12) return '#2E8B5F';   // green
    if (rate <= 0.22) return '#C9962E';   // amber caution
    if (rate <= 0.24) return '#D67124';   // deep amber bad
    if (rate <= 0.32) return '#C24A3A';   // red very bad
    if (rate <= 0.35) return '#A0322A';   // deeper red
    return '#7A1F18';                      // worst
  };
  const colors = brackets.map(b => severityColor(b.rate));

  return (
    <svg width={w} height={h} style={{ display: 'block' }}>
      {brackets.map((b, i) => {
        const x0 = i === 0 ? 0 : brackets[i-1].upto;
        const x1 = Math.min(b.upto, maxX);
        if (x0 >= maxX) return null;
        return (
          <g key={i}>
            <rect x={x(x0)} y={padT} width={x(x1)-x(x0)} height={20}
                  fill={colors[i]} />
            <text x={x(x0)+4} y={padT+34} fill="rgba(255,255,255,0.6)"
                  fontSize="9" fontFamily="JetBrains Mono, monospace">
              {(b.rate*100).toFixed(0)}%
            </text>
          </g>
        );
      })}
      <line x1={x(row.taxableIncome)} x2={x(row.taxableIncome)}
            y1={padT-6} y2={padT+26}
            stroke={P.ink} strokeWidth="2" />
      <text x={x(row.taxableIncome)} y={padT-10}
            fill={P.ink} fontSize="10" textAnchor="middle"
            fontFamily="JetBrains Mono, monospace">
        {window.fmt(row.taxableIncome)}
      </text>
      <text x={padL} y={h-10} fill={P.inkSoft} fontSize="10"
            fontFamily="Inter Tight, sans-serif" letterSpacing="0.06em">
        MARGINAL · {(row.marginal*100).toFixed(0)}%
      </text>
      <text x={w-padR} y={h-10} fill={P.inkSoft} fontSize="10"
            fontFamily="Inter Tight, sans-serif" letterSpacing="0.06em"
            textAnchor="end">
        EFFECTIVE · {row.grossIncome > 0 ? ((row.fedTax/row.grossIncome)*100).toFixed(1) : '0'}%
      </text>
    </svg>
  );
}

window.CashFlowBars = CashFlowBars;
window.BracketViz = BracketViz;
