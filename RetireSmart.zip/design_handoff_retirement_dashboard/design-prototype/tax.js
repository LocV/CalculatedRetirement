// US Federal tax engine — 2025 brackets, std deduction, SS taxability, RMDs.
// Plus: per-spouse retirement, Rule of 55, per-year income overrides,
// recurring expenses, Roth conversions.

const BRACKETS_2025 = {
  single: [
    { upto: 11925, rate: 0.10 }, { upto: 48475, rate: 0.12 },
    { upto: 103350, rate: 0.22 }, { upto: 197300, rate: 0.24 },
    { upto: 250525, rate: 0.32 }, { upto: 626350, rate: 0.35 },
    { upto: Infinity, rate: 0.37 },
  ],
  mfj: [
    { upto: 23850, rate: 0.10 }, { upto: 96950, rate: 0.12 },
    { upto: 206700, rate: 0.22 }, { upto: 394600, rate: 0.24 },
    { upto: 501050, rate: 0.32 }, { upto: 751600, rate: 0.35 },
    { upto: Infinity, rate: 0.37 },
  ],
};
const STD_DEDUCTION_2025 = { single: 15000, mfj: 30000 };
const EXTRA_DEDUCTION_65 = { single: 2000, mfj: 1600 };

function taxOnIncome(taxableIncome, filing) {
  if (taxableIncome <= 0) return 0;
  const brackets = BRACKETS_2025[filing];
  let tax = 0, prev = 0;
  for (const b of brackets) {
    const slice = Math.min(taxableIncome, b.upto) - prev;
    if (slice > 0) tax += slice * b.rate;
    if (taxableIncome <= b.upto) break;
    prev = b.upto;
  }
  return tax;
}
function marginalRate(taxableIncome, filing) {
  const brackets = BRACKETS_2025[filing];
  for (const b of brackets) if (taxableIncome <= b.upto) return b.rate;
  return brackets[brackets.length - 1].rate;
}
function taxableSocialSecurity(ssBenefit, otherIncome, filing) {
  if (ssBenefit <= 0) return 0;
  const provisional = otherIncome + 0.5 * ssBenefit;
  const t1 = filing === 'mfj' ? 32000 : 25000;
  const t2 = filing === 'mfj' ? 44000 : 34000;
  if (provisional <= t1) return 0;
  if (provisional <= t2) return Math.min(0.5 * (provisional - t1), 0.5 * ssBenefit);
  const part1 = Math.min(0.5 * ssBenefit, 0.5 * (t2 - t1));
  const part2 = 0.85 * (provisional - t2);
  return Math.min(0.85 * ssBenefit, part1 + part2);
}

const RMD_TABLE = {
  73: 26.5, 74: 25.5, 75: 24.6, 76: 23.7, 77: 22.9, 78: 22.0,
  79: 21.1, 80: 20.2, 81: 19.4, 82: 18.5, 83: 17.7, 84: 16.8,
  85: 16.0, 86: 15.2, 87: 14.4, 88: 13.7, 89: 12.9, 90: 12.2,
  91: 11.5, 92: 10.8, 93: 10.1, 94: 9.5, 95: 8.9, 96: 8.4,
  97: 7.8, 98: 7.3, 99: 6.8, 100: 6.4, 101: 6.0, 102: 5.6,
  103: 5.2, 104: 4.9, 105: 4.6,
};
function rmdDivisor(age) {
  if (age < 73) return null;
  if (age > 105) return 4.6;
  return RMD_TABLE[age] || null;
}

// Helper: compute how much taxable income you can add before crossing into a bracket.
function headroomToBracket(currentTaxableIncome, targetRate, filing) {
  const brackets = BRACKETS_2025[filing];
  for (const b of brackets) {
    if (b.rate >= targetRate) {
      return Math.max(0, b.upto - currentTaxableIncome);
    }
  }
  return Infinity;
}

// Inputs additions:
//   spendOverrides:  { [age]: { amount, label } }  (legacy: number is also accepted)
//   rothConversions: { [age]: amount }  — moves $amount from 401k to Roth that year,
//                                         taxed as ordinary income.
function project(input) {
  const {
    currentAge, retireAgeP1, retireAgeP2, spouseAgeOffset = 0, endAge,
    balance401k, balanceRoth, balanceTaxable, balanceCash = 0,
    contribution401k, employerMatch,
    returnRate, inflation,
    desiredSpend, spendOverrides = {},
    ssBenefit, ssStartAge,
    pension,
    workIncomeP1 = 0, workIncomeP2 = 0,
    otherIncome = 0,
    incomeOverrides = {},
    rothConversions = {},
    recurringExpenses = [],
    ruleOf55Age = null,
    filing,
    withdrawOrder = ['taxable', '401k', 'roth'],
  } = input;

  const normalizeBump = (v) => {
    if (v == null) return { amount: 0, label: '' };
    if (typeof v === 'number') return { amount: v, label: '' };
    return { amount: v.amount || 0, label: v.label || '' };
  };

  let b401k = balance401k, bRoth = balanceRoth, bTax = balanceTaxable, bCash = balanceCash;
  const rows = [];
  let depleted = null;

  for (let age = currentAge; age <= endAge; age++) {
    const yearsFromNow = age - currentAge;
    const inflationFactor = Math.pow(1 + inflation, yearsFromNow);
    const p1Working = age < retireAgeP1;
    const spouseAge = age + spouseAgeOffset;
    const p2Working = spouseAge < retireAgeP2;
    const anyoneWorking = p1Working || p2Working;
    const bothRetired = !anyoneWorking;

    // Investment growth
    const grow401k = b401k * returnRate;
    const growRoth = bRoth * returnRate;
    const growTax = bTax * returnRate;
    b401k += grow401k; bRoth += growRoth; bTax += growTax;

    // Contributions while P1 still working
    let contrib = 0;
    if (p1Working) {
      contrib = (contribution401k + employerMatch) * inflationFactor;
      b401k += contrib;
    }

    // Income — per spouse, with optional per-year overrides
    const ov = incomeOverrides[age] || {};
    const baseP1 = ov.wagesP1 != null ? ov.wagesP1 : (p1Working ? workIncomeP1 : 0);
    const baseP2 = ov.wagesP2 != null ? ov.wagesP2 : (p2Working ? workIncomeP2 : 0);
    const baseOther = ov.other != null ? ov.other : otherIncome;
    const wagesThisYear = (baseP1 + baseP2) * inflationFactor;
    const otherThisYear = baseOther * inflationFactor;
    const ssThisYear = (age >= ssStartAge && bothRetired) ? ssBenefit * inflationFactor : 0;
    const pensionThisYear = bothRetired ? pension * inflationFactor : 0;

    // Expenses (with labeled bumps)
    const bump = normalizeBump(spendOverrides[age]);
    const overrideExtra = bump.amount * inflationFactor;
    const overrideLabel = bump.label;
    const baselineSpend = desiredSpend * inflationFactor;
    const recurringTotal = recurringExpenses.reduce((sum, e) => {
      const start = e.startAge ?? currentAge;
      const end = e.endAge ?? endAge;
      if (age >= start && age <= end) return sum + (e.amount || 0) * inflationFactor;
      return sum;
    }, 0);
    const targetSpend = baselineSpend + overrideExtra + recurringTotal;

    // RMD
    const div = rmdDivisor(age);
    const rmd = (div && b401k > 0) ? b401k / div : 0;

    // Rule of 55
    const ruleOf55Active = ruleOf55Age != null && age >= ruleOf55Age;
    const canTap401k = !p1Working || age >= 59.5 || ruleOf55Active;

    const guaranteedIncome = wagesThisYear + otherThisYear + ssThisYear + pensionThisYear;
    let cashNeeded = Math.max(0, targetSpend - guaranteedIncome);

    let w401k = 0, wRoth = 0, wTax = 0, fromCash = 0, w401kRMD = 0;

    // Roth conversion FIRST — taxable but doesn't reduce cashNeeded (money stays invested)
    let rothConv = (rothConversions[age] || 0) * inflationFactor;
    if (rothConv > 0) {
      const take = Math.min(rothConv, b401k);
      b401k -= take;
      bRoth += take;
      rothConv = take;
    }

    // RMDs — forced
    if (rmd > 0) {
      const take = Math.min(rmd, b401k);
      w401k += take;
      w401kRMD = take;
      b401k -= take;
      cashNeeded = Math.max(0, cashNeeded - take);
    }

    if (!p1Working && cashNeeded > 0) {
      for (const src of withdrawOrder) {
        if (cashNeeded <= 0) break;
        if (src === 'taxable' && bTax > 0) {
          const t = Math.min(cashNeeded, bTax);
          wTax += t; bTax -= t; cashNeeded -= t;
        } else if (src === '401k' && b401k > 0 && canTap401k) {
          const t = Math.min(cashNeeded, b401k);
          w401k += t; b401k -= t; cashNeeded -= t;
        } else if (src === 'roth' && bRoth > 0) {
          const t = Math.min(cashNeeded, bRoth);
          wRoth += t; bRoth -= t; cashNeeded -= t;
        }
      }
      if (cashNeeded > 0 && bCash > 0) {
        const t = Math.min(cashNeeded, bCash);
        fromCash += t; bCash -= t; cashNeeded -= t;
      }
    }

    // Tax: wages + other + 401k withdrawals + pension + Roth conversion + taxable SS
    const ordinaryBeforeSS = wagesThisYear + otherThisYear + w401k
                           + pensionThisYear + rothConv;
    const taxableSS = taxableSocialSecurity(ssThisYear, ordinaryBeforeSS, filing);
    const grossIncome = ordinaryBeforeSS + taxableSS;
    const stdDed = (STD_DEDUCTION_2025[filing] + (age >= 65 ? EXTRA_DEDUCTION_65[filing] : 0)) * inflationFactor;
    const taxableIncome = Math.max(0, grossIncome - stdDed);
    const fedTax = taxOnIncome(taxableIncome, filing);
    const marginal = marginalRate(taxableIncome, filing);

    // Bracket headroom — useful for the conversion editor
    const headroom12 = headroomToBracket(taxableIncome, 0.22, filing);
    const headroom22 = headroomToBracket(taxableIncome, 0.24, filing);
    const headroom24 = headroomToBracket(taxableIncome, 0.32, filing);

    let cashAdded = 0;
    if (anyoneWorking) {
      const afterTax = wagesThisYear + otherThisYear - fedTax;
      const contribOut = p1Working ? contribution401k * inflationFactor : 0;
      const netCash = afterTax - targetSpend - contribOut;
      if (netCash > 0) { bCash += netCash; cashAdded = netCash; }
      else if (netCash < 0 && bCash > 0) {
        const pull = Math.min(bCash, -netCash);
        bCash -= pull; fromCash += pull;
      }
    }

    const grossCash = wagesThisYear + otherThisYear + ssThisYear + pensionThisYear
                    + w401k + wRoth + wTax + fromCash;
    const netSpend = grossCash - fedTax;
    const totalAssets = b401k + bRoth + bTax + bCash;
    if (totalAssets <= 0 && depleted === null && bothRetired) depleted = age;

    rows.push({
      age, spouseAge,
      year: new Date().getFullYear() + yearsFromNow,
      p1Working, p2Working, isWorking: anyoneWorking,
      b401k, bRoth, bTax, bCash, totalAssets,
      grow401k, growRoth, growTax,
      contrib, cashAdded,
      wages: wagesThisYear, wagesP1: baseP1 * inflationFactor, wagesP2: baseP2 * inflationFactor,
      other: otherThisYear,
      ss: ssThisYear, pension: pensionThisYear,
      targetSpend, baselineSpend, overrideExtra, overrideLabel, recurringTotal,
      w401k, w401kRMD, w401kVoluntary: w401k - w401kRMD,
      wRoth, wTax, fromCash, rmd,
      rothConv,
      ruleOf55Active, canTap401k,
      grossIncome, taxableIncome, fedTax, marginal,
      headroom12, headroom22, headroom24,
      netSpend, shortfall: Math.max(0, targetSpend - netSpend),
    });

    if (totalAssets <= 0 && bothRetired) {
      b401k = Math.max(0, b401k); bRoth = Math.max(0, bRoth);
      bTax = Math.max(0, bTax); bCash = Math.max(0, bCash);
    }
  }

  return { rows, depleted, brackets: BRACKETS_2025[filing] };
}

window.RetireMath = {
  project, taxOnIncome, marginalRate, taxableSocialSecurity, rmdDivisor,
  headroomToBracket, BRACKETS_2025, STD_DEDUCTION_2025,
};
