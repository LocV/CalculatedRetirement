// panels.jsx — floating, draggable control panels that "pop out" from chips
const { useState: _pUseState, useEffect: _pUseEffect, useRef: _pUseRef } = React;

function FloatingPanel({ id, title, anchor, onClose, children, width = 320 }) {
  // Position: spawn from anchor point, then user can drag.
  const [pos, setPos] = _pUseState(() => {
    const ax = anchor?.x ?? 200;
    const ay = anchor?.y ?? 200;
    // Keep within viewport
    const vw = window.innerWidth, vh = window.innerHeight;
    return {
      x: Math.min(vw - width - 24, Math.max(24, ax + 16)),
      y: Math.min(vh - 320, Math.max(24, ay + 16)),
    };
  });
  const [appeared, setAppeared] = _pUseState(false);
  const [origin] = _pUseState(() => ({
    x: (anchor?.x ?? pos.x + width/2) - pos.x,
    y: (anchor?.y ?? pos.y) - pos.y,
  }));
  const dragRef = _pUseRef(null);

  _pUseEffect(() => {
    requestAnimationFrame(() => setAppeared(true));
  }, []);

  const onMouseDown = (e) => {
    if (e.target.closest('.no-drag')) return;
    const start = { mx: e.clientX, my: e.clientY, x: pos.x, y: pos.y };
    const move = (ev) => {
      setPos({
        x: Math.max(8, Math.min(window.innerWidth - width - 8, start.x + ev.clientX - start.mx)),
        y: Math.max(8, Math.min(window.innerHeight - 80,        start.y + ev.clientY - start.my)),
      });
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };

  return (
    <div
      ref={dragRef}
      onMouseDown={onMouseDown}
      style={{
        position: 'fixed',
        left: pos.x, top: pos.y, width,
        background: 'rgba(18, 28, 38, 0.96)',
        backdropFilter: 'blur(20px) saturate(140%)',
        WebkitBackdropFilter: 'blur(20px) saturate(140%)',
        border: '1px solid rgba(212, 179, 106, 0.22)',
        borderRadius: 6,
        boxShadow: '0 24px 60px rgba(0,0,0,0.55), 0 2px 8px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.04)',
        color: '#F5F1E8',
        fontFamily: '"Inter Tight", system-ui, sans-serif',
        zIndex: 100,
        cursor: 'move',
        transformOrigin: `${origin.x}px ${origin.y}px`,
        transform: appeared ? 'scale(1)' : 'scale(0.6)',
        opacity: appeared ? 1 : 0,
        transition: 'transform 240ms cubic-bezier(0.34, 1.4, 0.5, 1), opacity 180ms ease-out',
      }}
    >
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '10px 14px',
        borderBottom: '1px solid rgba(212, 179, 106, 0.14)',
      }}>
        <div style={{
          fontSize: 10, letterSpacing: '0.14em',
          color: 'rgba(212, 179, 106, 0.85)',
          fontWeight: 600, textTransform: 'uppercase',
        }}>{title}</div>
        <button
          className="no-drag"
          onClick={onClose}
          style={{
            border: 'none', background: 'transparent', cursor: 'pointer',
            color: 'rgba(245,241,232,0.5)', fontSize: 16, lineHeight: 1,
            padding: 0, width: 18, height: 18,
          }}
          onMouseEnter={e => e.currentTarget.style.color = '#F5F1E8'}
          onMouseLeave={e => e.currentTarget.style.color = 'rgba(245,241,232,0.5)'}
        >×</button>
      </div>
      <div className="no-drag" style={{ padding: '14px 16px 18px', cursor: 'default' }}>
        {children}
      </div>
    </div>
  );
}

// Reusable controls
function NumberRow({ label, value, onChange, min = 0, max = 1e9, step = 1, prefix = '$', suffix = '' }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  padding: '8px 0', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
      <div style={{ fontSize: 12, color: 'rgba(245,241,232,0.78)' }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 4,
                    background: 'rgba(255,255,255,0.04)',
                    border: '1px solid rgba(255,255,255,0.08)',
                    borderRadius: 4, padding: '3px 6px' }}>
        {prefix && <span style={{ fontSize: 11, color: 'rgba(212,179,106,0.8)',
                                  fontFamily: 'JetBrains Mono, monospace' }}>{prefix}</span>}
        <input
          type="number" value={value}
          min={min} max={max} step={step}
          onChange={e => onChange(parseFloat(e.target.value) || 0)}
          style={{
            width: 80, background: 'transparent', border: 'none', outline: 'none',
            color: '#F5F1E8', fontFamily: 'JetBrains Mono, monospace',
            fontSize: 12, textAlign: 'right',
          }}
        />
        {suffix && <span style={{ fontSize: 11, color: 'rgba(245,241,232,0.5)' }}>{suffix}</span>}
      </div>
    </div>
  );
}

function SliderRow({ label, value, onChange, min, max, step, format }) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div style={{ padding: '10px 0', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
        <span style={{ fontSize: 12, color: 'rgba(245,241,232,0.78)' }}>{label}</span>
        <span style={{ fontSize: 12, color: '#D4B36A',
                       fontFamily: 'JetBrains Mono, monospace' }}>
          {format ? format(value) : value}
        </span>
      </div>
      <div style={{ position: 'relative', height: 4,
                    background: 'rgba(255,255,255,0.08)', borderRadius: 2 }}>
        <div style={{
          position: 'absolute', left: 0, top: 0, bottom: 0,
          width: pct + '%',
          background: 'linear-gradient(90deg, rgba(212,179,106,0.5), #D4B36A)',
          borderRadius: 2,
        }} />
        <input
          type="range" value={value} min={min} max={max} step={step}
          onChange={e => onChange(parseFloat(e.target.value))}
          style={{
            position: 'absolute', inset: '-8px 0', width: '100%', height: 20,
            opacity: 0, cursor: 'pointer',
          }}
        />
        <div style={{
          position: 'absolute', left: `calc(${pct}% - 6px)`, top: -4,
          width: 12, height: 12, borderRadius: '50%',
          background: '#F5F1E8', border: '2px solid #D4B36A',
          pointerEvents: 'none',
        }} />
      </div>
    </div>
  );
}

function SegRow({ label, value, options, onChange }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  padding: '8px 0', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
      <div style={{ fontSize: 12, color: 'rgba(245,241,232,0.78)' }}>{label}</div>
      <div style={{ display: 'flex', background: 'rgba(255,255,255,0.04)',
                    border: '1px solid rgba(255,255,255,0.08)',
                    borderRadius: 4, padding: 2 }}>
        {options.map(opt => (
          <button key={opt.value}
            onClick={() => onChange(opt.value)}
            style={{
              border: 'none', cursor: 'pointer', padding: '4px 10px', borderRadius: 3,
              fontSize: 11, fontWeight: 500, letterSpacing: '0.04em',
              fontFamily: 'Inter Tight, sans-serif',
              background: value === opt.value ? 'rgba(212,179,106,0.18)' : 'transparent',
              color: value === opt.value ? '#D4B36A' : 'rgba(245,241,232,0.6)',
              transition: 'all 120ms',
            }}>
            {opt.label}
          </button>
        ))}
      </div>
    </div>
  );
}

window.FloatingPanel = FloatingPanel;
window.NumberRow = NumberRow;
window.SliderRow = SliderRow;
window.SegRow = SegRow;
