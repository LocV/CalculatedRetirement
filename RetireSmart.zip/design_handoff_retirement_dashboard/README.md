# Handoff: RetireSmart — Drawdown Atlas

A retirement projection dashboard and calculator. The user enters current
balances, contributions, expected returns, retirement ages, Social Security,
pension, recurring expenses, and one-off "spend bumps", and the app projects
year-by-year balances, withdrawals, federal taxes, and net spending until a
configured end age.

---

## About the Design Files

The files in `design-prototype/` are **design references created in HTML +
inline-Babel JSX**. They are a working prototype that demonstrates intended
look and behavior — they are NOT production code to copy verbatim.

Your job is to **recreate this design in the target codebase** using its
established framework, libraries, and patterns. If no codebase exists yet,
React + TypeScript + Vite is the natural fit (the prototype is already in
React 18); pair with Recharts or Visx for charting and Zustand or React
Context for state.

The prototype mounts via inline `<script type="text/babel">` tags on a
single HTML page; in production you will:
- Convert each `.jsx` file into a proper module with `import`/`export`
- Replace `window.PALETTE`, `window.fmt`, `window.project`, etc. with
  imports
- Move all inline `style={{...}}` to your styling system of choice
  (CSS Modules, Tailwind, styled-components, vanilla-extract — whatever
  the codebase uses)
- Replace the in-component state with whatever store the codebase uses
- Add TypeScript types for the projection row, inputs, and panel state

## Fidelity

**High-fidelity.** Final colors, typography, spacing, layouts, and
interactions are all locked. The financial model in `tax.js` is also
production-quality — preserve its math exactly. The full list of design
tokens is below; copy them verbatim.

---

## App Structure

The app is a **single page** with these regions, top to bottom:

1. **Header** — brand mark, title "Drawdown Atlas", subtitle, and two
   inline-edit chips (filing status, age horizon).
2. **KPI strip** — 4 large stat tiles (Total today / At retirement / Annual
   spend / Lifetime tax). Three are clickable to open edit panels.
3. **Hero card: Cash Flow** — full-width stacked bar chart showing income
   sources and expense buckets per year, with the year hover scrubber and
   inline tweak chips above it.
4. **Two-column row**:
   - **Net Worth Over Time** — stacked area chart of 401(k) / Taxable / Roth
     / Cash balances projected to end-of-life.
   - **This Year — Detailed Breakdown** — drilldown of the hovered year:
     income sources, withdrawals, expenses, tax, net spendable, ending
     balance.
5. **Tax bracket bar** — horizontal rate bar visualizing the federal
   marginal-rate progression for the hovered year, color-coded by severity.
6. **Footer** — disclosure copy.
7. **Floating panels** — opened from any chip; draggable, dockable, dismiss
   on outside click.
8. **Income editor overlay** — full-screen modal opened from a chip;
   per-year wage editor with presets.

There are no other routes or screens.

---

## Screens / Views

### 1. Header

- **Layout**: 28px top padding, 36px side padding. Flex row, space-between,
  `align-items: flex-start`, gap 12px.
- **Brand mark** (left): 8×8px square rotated 45° in `account401k` green
  (#3FA76B), then "RETIRESMART" in 11px Inter Tight 600, letter-spacing
  0.22em, same green color.
- **Title**: `<h1>` "Drawdown Atlas" in 34px Inter Tight 500, letter-spacing
  -0.02em, line-height 1.05.
- **Subtitle**: 13px, color `inkSoft`, max-width 540px. Copy: "Year-by-year
  projection of assets, income, expenses, and taxes. Hover the chart to
  inspect a year. Click any chip to edit assumptions."
- **Right chips**: two `Chip` components — filing status (`Filing ·
  Married/Joint` or `Filing · Single`) and horizon (`Plan · 58 → 95`).

### 2. KPI Strip

- **Layout**: 4-column CSS grid, gap 1px, top-margin 24px. Background
  `borderSoft` to create hairline separators between tiles.
- **Each tile** (`Kpi` component, ~140px tall):
  - 10px label, uppercase, letter-spacing 0.18em, color `inkSoft`
  - 24px JetBrains Mono number with margin-top 8px
  - 11px sub-label, color `inkSofter`
  - If clickable, an "EDIT ↗" hint top-right in 9px green
  - Background `rgba(15,28,24,0.92)`; hover `rgba(20,38,30,0.95)`
  - Padding 18px

The four tiles:

| Tile | Value | Sub | Action |
|---|---|---|---|
| TOTAL TODAY | sum of all balances today | "Age 58" | Opens accounts panel |
| AT RETIREMENT · 65 | projected balance at retire age | "After tax-deferred growth" | Opens retirement panel |
| ANNUAL SPEND | desiredSpend (today's $) | "today's dollars" | Opens spend panel |
| LIFETIME TAX | sum of fedTax across all years | "Federal, lifetime" | (read-only) |

### 3. Hero Card: Cash Flow

- **Card chrome** (`Card` component): linear-gradient
  `rgba(20,34,28,0.7) → rgba(15,28,24,0.7)`, 1px `borderSoft` border,
  border-radius 6px, padding 18/20/22px.
- **CardHeader**: eyebrow "INCOME · EXPENSES · TAXES" in 10px 600
  letter-spacing 0.2em, then 18px title "Cash Flow".
- **Tweak chip row** below header — wraps; chips are `Chip small` variants:
  - `P1 retire · 65`, `P2 retire · 65` (open `retire` panel)
  - `Wages · $200k/yr` (open `income` panel)
  - `SS · $38,400/yr @ 67` (open `ss` panel)
  - `Recurring · 2 items` (open `recurring` panel)
  - `Bumps · 2` (open `spend` panel)
  - `Roth conv · 0` (open `roth` panel)
  - `Fine-tune by year →` (opens income editor overlay)
- **Chart**: stacked bar chart, 360px tall.
  - Positive Y bars are income, ordered bottom-to-top: wages, other, SS,
    pension, 401(k) withdrawal, taxable withdrawal, Roth withdrawal, cash
    draw.
  - Negative Y bars are expenses: federal tax (red), recurring (dim spend),
    bumps (deeper amber), baseline spend (yellow).
  - Hover scrubs `hoverAge` state, which is consumed by the YearDetail
    drawer and the bracket bar.

### 4. Net Worth Over Time

- Card with title "Net Worth Over Time".
- Chart: 320px stacked area chart.
- Series (bottom to top): 401(k) → Taxable → Roth → Cash.
- Colors: greens from the palette (account401k → accountTax → accountRoth
  → accountCash).
- Vertical guide line at retirement age.
- Y-axis formatted with `$Xk` / `$X.XM`.

### 5. This Year — Detailed Breakdown

`YearDetail` component. Renders only when `hoverAge` is set; otherwise an
empty 14px hint "Hover the chart to see year details."

Sections:
1. **INCOME** (label color `wages`):
   Wages, Other income, Social Security, Pension, 401(k) w/d (with sub
   "RMD floor: $X" if RMD applies, "unlocked via Rule of 55" if eligible
   pre-59½, or "locked until 59½" otherwise), Roth w/d, Taxable w/d, From
   cash.
2. **EXPENSES** (label color `spend`):
   Baseline spend, Recurring, Extra bump (with `· <label>` if labeled,
   color `spendBump`), Roth conversion (only if > 0, color `accountTax`,
   sub "401(k) → Roth (taxable)"), ⚠ RMD (forced) (only if > 0, color
   `danger`), Federal tax (sub "marginal X%", color `tax`).
3. **Summary**: Net spendable (big, color `good`), Ending balance (big,
   color `account401k`), ⚠ Shortfall if any (color `danger`).

`Row` component: flex row, `justify-content: space-between`. Key in 12px
inkSoft. Value in JetBrains Mono 12px (or 14px if `big`). Optional sub in
9.5px inkSofter mono.

### 6. Tax Bracket Bar

- Horizontal full-width bar showing current year's gross income mapped onto
  the federal bracket structure.
- Each bracket is a flex segment proportional to its width.
- **Severity coloring** (taxable income up to top of each bracket):
  - 10% / 12% → green tints (good)
  - 22% → amber (caution)
  - 24% → deep amber (bad)
  - 32% / 35% / 37% → reds (very bad → worst)
- The user's current taxable income is marked with a tick on the bar.

### 7. Floating Panels

`panels.jsx` provides the panel chrome. When a chip is clicked, the chip
records the anchor rect; `setOpenPanel({ id, anchor })`. A draggable
floating window opens near the anchor with that panel's content.

Panels and what they edit:

| id | Title | Edits |
|---|---|---|
| `filing` | Filing status | `filing` ('mfj' or 'single') |
| `horizon` | Plan horizon | `currentAge`, `endAge` |
| `accounts` | Account balances | balance401k, balanceRoth, balanceTaxable, balanceCash, contribution401k, employerMatch |
| `retire` | Retirement timing | retireAgeP1, retireAgeP2, spouseAgeOffset, ruleOf55Age |
| `income` | Working income | workIncomeP1, workIncomeP2, otherIncome |
| `ss` | Social Security | ssBenefit, ssStartAge |
| `pension` | Pension | pension |
| `growth` | Returns / Inflation | returnRate, inflation |
| `spend` | Spending + bumps | desiredSpend + spendOverrides (per-year labeled extras) |
| `recurring` | Recurring expenses | recurringExpenses[] |
| `roth` | Roth conversions | rothConversions per-year + bracket-fill presets |

All panels share these row primitives (defined in the prototype):
- `NumberRow` — labeled number input
- `SliderRow` — labeled slider with a formatter
- `SegRow` — segmented two/three-way toggle

### 8. Income Editor Overlay

Full-screen modal (z-index above everything). A scrollable table with one
row per projection year, columns: Age, Status (Both work / P1 only / P2
only / Retired), P1 wages, P2 wages, Other, ↺ reset.

Edits write to `state.incomeOverrides[age] = { wagesP1?, wagesP2?, other? }`.
Two preset buttons: "P1 part-time 3 yrs @ 50%" and "P2 part-time 3 yrs @
50%".

---

## Interactions & Behavior

- **Hover**: hovering the cash flow chart sets `hoverAge`, which scrubs the
  YearDetail drawer and the tax bracket bar in real time.
- **Chip click**: opens a floating panel anchored to that chip. Clicking
  outside the panel (or pressing Esc) closes it.
- **Panel drag**: panels are draggable by their header.
- **Live updates**: every state change re-runs `project()` (via
  `useMemo`); chart, KPIs, and drawer all reflect the new projection
  immediately. No "Apply" button anywhere — direct manipulation.
- **Persistence**: not implemented; defaults are inline. Production should
  persist `state` to localStorage or the user's account.
- **Tweaks** (prototype only): the prototype uses an EDITMODE-BEGIN/END
  comment block and `__edit_mode_set_keys` postMessage to support the
  hosting tool's tweak system. Drop this in production — replace with your
  own state management.

### Animations / Transitions

- Chip hover: `transition: all 140ms` (background lightens).
- KPI tile hover: `transition: background 160ms`.
- Panel drag: instant, no transition.
- No mount animations on the charts — they update synchronously.

---

## State Management

A single state object holds all inputs:

```ts
type Filing = 'mfj' | 'single';

interface RecurringExpense {
  label: string;
  amount: number;        // today's $/year
  startAge: number;
  endAge: number;
}

interface SpendBump {
  amount: number;        // today's $
  label: string;
}

interface IncomeOverride {
  wagesP1?: number;      // absolute, today's $; undefined = use default
  wagesP2?: number;
  other?: number;
}

interface PlanState {
  // Ages
  currentAge: number;
  retireAgeP1: number;
  retireAgeP2: number;
  spouseAgeOffset: number;     // P2.age - P1.age
  ruleOf55Age: number | null;  // null = disabled
  endAge: number;

  // Balances (today's $)
  balance401k: number;
  balanceRoth: number;
  balanceTaxable: number;
  balanceCash: number;

  // Contributions while working
  contribution401k: number;    // employee, today's $
  employerMatch: number;

  // Assumptions
  returnRate: number;          // 0.06 = 6%/yr nominal
  inflation: number;           // 0.025 = 2.5%/yr

  // Spending
  desiredSpend: number;
  spendOverrides: Record<number, SpendBump | number>; // legacy number accepted
  recurringExpenses: RecurringExpense[];

  // Income
  ssBenefit: number;           // today's $/yr
  ssStartAge: number;
  pension: number;
  workIncomeP1: number;
  workIncomeP2: number;
  otherIncome: number;
  incomeOverrides: Record<number, IncomeOverride>;

  // Tax
  filing: Filing;

  // Strategy
  rothConversions: Record<number, number>;  // age → today's $ to convert
}
```

Plus UI-only state:
- `hoverAge: number | null`
- `openPanel: { id: PanelId; anchor: { x: number; y: number } } | null`
- `showIncomeEditor: boolean`

All inputs flow into `project(state) → ProjectionRow[]`.

---

## The Projection Engine (`tax.js`)

This is the single source of truth for the math. Reproduce it exactly.
Recommended approach: copy `tax.js` into `src/lib/projection.ts`, add
TypeScript types, and write unit tests against the existing default state
(should match the prototype's chart byte-for-byte).

### Inputs

See `PlanState` above plus a `withdrawOrder: ('taxable'|'401k'|'roth')[]`
(default `['taxable','401k','roth']`).

### Output: one row per year, age `currentAge..endAge`

```ts
interface ProjectionRow {
  age: number;
  yearsFromNow: number;
  inflationFactor: number;      // (1+inflation)^yearsFromNow

  // Balances at end of year (after growth, contributions, withdrawals)
  b401k: number;
  bRoth: number;
  bTaxable: number;
  bCash: number;
  totalAssets: number;

  // Income (nominal $ that year)
  wages: number;
  other: number;
  ss: number;
  pension: number;

  // Spending breakdown
  baselineSpend: number;
  recurringTotal: number;
  overrideExtra: number;
  overrideLabel: string;
  targetSpend: number;          // sum of the above

  // Withdrawals (nominal $)
  w401k: number;                // total from 401k
  w401kRMD: number;             // forced portion
  w401kVoluntary: number;       // = w401k - w401kRMD
  wRoth: number;
  wTax: number;                 // taxable account
  fromCash: number;
  rmd: number;                  // RMD requirement (info)
  rothConv: number;             // converted 401k → Roth this year

  // Gates
  ruleOf55Active: boolean;
  canTap401k: boolean;

  // Tax
  grossIncome: number;
  taxableIncome: number;        // after standard deduction & SS taxability
  fedTax: number;
  marginal: number;             // marginal rate, e.g. 0.22
  headroom12: number;           // $ to top of 12% bracket
  headroom22: number;
  headroom24: number;

  // Outcomes
  netSpend: number;             // what's actually available after tax
  shortfall: number;            // if assets can't cover targetSpend
}
```

### Algorithm

For each year from `currentAge` to `endAge`:

1. **Growth**: each balance multiplied by `(1 + returnRate)`.
2. **Contributions**: while `age < retireAgeP1`, add
   `(contribution401k + employerMatch) * inflationFactor` to b401k.
3. **Income**:
   - Wages: P1 earns `workIncomeP1` while `age < retireAgeP1`; P2 earns
     `workIncomeP2` while `(age + spouseAgeOffset) < retireAgeP2`. Multiply
     by `inflationFactor`. Per-year override in `incomeOverrides[age]` wins.
   - SS: only when **both** spouses retired AND `age >= ssStartAge`.
   - Pension: only when both retired.
4. **Expenses**: baseline + active recurring expenses + spend bump (if
   any), all scaled by `inflationFactor`.
5. **RMD**: if `age >= 73`, divide b401k by the IRS Uniform Lifetime Table
   divisor. Force a withdrawal of at least RMD even if not needed for cash.
6. **Rule of 55**: `ruleOf55Active = ruleOf55Age != null && age >= ruleOf55Age`.
   `canTap401k = !p1Working || age >= 59.5 || ruleOf55Active`.
7. **Roth conversion**: if `rothConversions[age] > 0`, move that amount
   (scaled by inflation) from b401k to bRoth. Counts as ordinary income;
   does NOT reduce cash needed.
8. **Cash needed** = `max(0, targetSpend - guaranteedIncome)` where
   guaranteed = wages + other + SS + pension. Withdraw from accounts in
   `withdrawOrder` (skipping 401k if `!canTap401k`).
9. **Tax**:
   - Gross income = wages + other + 401k withdrawal + Roth conversion +
     pension + taxable interest (modeled as 0 for simplicity) + taxable
     portion of SS (per the IRS provisional-income rules — see `tax.js`).
   - Standard deduction by filing status (2025 brackets, MFJ $30,000,
     Single $15,000 — confirm before launch).
   - Apply 2025 marginal brackets (10/12/22/24/32/35/37%).
   - `marginal` = the bracket the LAST dollar of taxable income fell into.
10. **Net spend** = total cash withdrawn + guaranteed income − fedTax.
11. **Shortfall** = `max(0, targetSpend - actualSpend)` when balances
    deplete.

The full implementation including the SS-taxability calculation, RMD table,
and bracket math is in `design-prototype/tax.js`. **Read it carefully** —
do not rewrite from scratch.

---

## Design Tokens

### Color Palette (from `colors.js`)

```ts
export const palette = {
  // Accounts (you have this money) — greens
  account401k:    '#3FA76B',
  accountTax:     '#5FBF8F',
  accountRoth:    '#86D6AC',
  accountCash:    '#B8E5C9',

  // Spending — yellow/amber
  spend:          '#F2C94C',
  spendDim:       'rgba(242, 201, 76, 0.5)',
  spendBump:      '#F2A93C',

  // Income — cool/neutral
  wages:          '#7AB8D4',
  other:          '#A89BD4',
  ss:             '#6FB5A8',
  pension:        '#B89BD4',

  // Tax — red
  tax:            '#E0584C',
  taxDim:         'rgba(224, 88, 76, 0.6)',

  // UI
  ink:            '#F2F1EC',
  inkSoft:        'rgba(242, 241, 236, 0.6)',
  inkSofter:      'rgba(242, 241, 236, 0.4)',
  bgDeep:         '#0A1410',
  bgMid:          '#0F1C18',
  bgLift:         'rgba(20, 34, 28, 0.7)',
  borderSoft:     'rgba(255, 255, 255, 0.06)',
  borderAccent:   'rgba(63, 167, 107, 0.22)',

  // States
  good:           '#7CD4A8',
  danger:         '#E0584C',
};
```

### Page background

Radial gradient: `radial-gradient(ellipse at top, #0F2419 0%, #0A1410 60%, #060A08 100%)`.

### Typography

- **Display + UI**: Inter Tight (Google Fonts), weights 400/500/600.
- **Numbers / mono**: JetBrains Mono, weights 400/500.
- All numeric values (KPIs, table rows, axis labels, bracket bar) MUST
  render in JetBrains Mono — it is core to the editorial-data feel.

Type scale (px):
| Use | Size | Weight | Letter-spacing |
|---|---|---|---|
| Page H1 | 34 | 500 | -0.02em |
| KPI value | 24 | 500 | -0.01em |
| Card title | 18 | 500 | -0.01em |
| Body | 13 | 400 | 0 |
| Row label | 12 | 400 | 0 |
| Row value | 12 (14 if big) | 400 (mono) | 0 |
| Small text | 11 | 400 | 0 |
| Eyebrow | 10 | 600 | 0.18–0.22em (uppercase) |
| Sub-eyebrow | 9.5 | 400 | 0 |
| Tick / badge | 9 | 600 | 0.1–0.18em (uppercase) |

### Spacing

Page outer padding: `28px 36px 60px`. Card padding: `18px 20px 22px`.
Card-to-card gap: 20px. Inside cards, vertical rhythm 6–14px.

### Border radius

- Cards: 6px
- KPI tiles: 4px
- Buttons / chips (pill): 999px
- Inputs / small buttons: 4px

### Shadows

The design uses borders + lift backgrounds rather than drop shadows. Floating
panels use `0 16px 40px rgba(0,0,0,0.6)` with a 1px borderSoft border.

---

## Charts

The prototype rolls its own SVG charts (no library). For production, use
**Recharts** or **Visx**:

- **Cash flow** → Recharts `BarChart` with `stackId="income"` (positive)
  and `stackId="expense"` (negative, via `Math.abs` and a custom Y axis).
  Or Visx `BarStack` with a divergent y-domain.
- **Net worth** → Recharts `AreaChart` with `stackOffset="none"`.
- **Tax bracket bar** → plain CSS flex. No library needed.

Hover sync: a single `hoverAge` state in the parent. Pass `onMouseMove` →
extract the active payload's age → `setHoverAge`. The drawer and bracket
bar both subscribe.

---

## Assets

- **Fonts**: Inter Tight + JetBrains Mono via Google Fonts.
- **Icons / images**: none. The design is type + color + geometry only.
- **Brand mark**: a 45°-rotated 8×8px square, no logo file needed.

---

## Files in `design-prototype/`

| File | Role |
|---|---|
| `RetireSmart Dashboard.html` | Host page — fonts, base styles, script tags |
| `colors.js` | Sets `window.PALETTE` |
| `tax.js` | Projection engine — **the financial source of truth** |
| `chart.jsx` | Cash flow + net worth charts |
| `extras.jsx` | Tax bracket bar, year detail drawer, helpers |
| `panels.jsx` | Floating panel chrome + drag |
| `app.jsx` | Top-level layout, state, KPIs, panel routing, income editor |
| `tweaks-panel.jsx` | Tweak system shim — drop in production |

To run the prototype: serve the folder over any static HTTP server (e.g.
`npx serve design-prototype`) and open `RetireSmart Dashboard.html`. It
needs network access for the React + Babel CDN scripts and Google Fonts.

---

## Recommended Production Stack

If starting from scratch:
- **Vite + React 18 + TypeScript**
- **State**: Zustand (simple, fits this single-blob shape) or React Context
- **Charts**: Recharts (faster to build) or Visx (more control)
- **Styling**: Tailwind with the palette extended in `tailwind.config`, OR
  vanilla-extract with the token map above. The inline-style soup in the
  prototype should NOT be the production approach.
- **Numbers**: keep all financial math in pure functions (`projection.ts`,
  `tax.ts`) with unit tests. The UI should never reach into bracket
  calculations.
- **Persistence**: localStorage for v1; user accounts later.

## Things to Verify Before Shipping

1. **2025 tax brackets and standard deduction** — confirm values in
   `tax.js` against current IRS publications.
2. **Social Security taxability thresholds** — these have not been
   inflation-adjusted in years, but verify.
3. **RMD age** — currently 73 (SECURE 2.0). Confirm.
4. **Disclaimer copy** — the current footer is informational only; legal
   should review before any real-money advice.
5. **Edge cases** — depleted accounts, age >= endAge, ruleOf55Age <
   currentAge, negative inputs, single filer with spouse fields populated.
